<?
//Session On
session_start();
//Connect With Database
include_once("../../includes/config.php");
$_SESSION['trainer']['begin_zien'] = 0;
?>