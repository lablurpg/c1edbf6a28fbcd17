<?
header("Location: ../../?page=notfound");