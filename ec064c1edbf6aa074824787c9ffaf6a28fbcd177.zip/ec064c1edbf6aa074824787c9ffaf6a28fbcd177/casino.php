<?php
//Load script so you can never load page outside of the index
include("includes/security.php");
?>

<div class="content">

    <div style="float: right;" >
        <img src="images/casino.gif" >
    </div>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

    <a href="?page=multiblackjack"><h1>Blackjack multiplayer<span style="color:red; font-size:bold;"><sup>new</sup></h1></span></a>
    <a href="?page=flip-a-coin"><h1>Heads or tail</h1></a>
    <a href="?page=slots"><h1>Pok&eacute;slots<span style="color:red; font-size:bold;"><sup>new</sup></h1></span></a>
    <a href="?page=who-is-it-quiz"><h1>Who is it quiz</h1></a>
    <a href="?page=wheel-of-fortune"><h1>Wheel of Fortune</h1></a>
    <a href="?page=poke-scrambler"><h1>Pok&eacute;mon name</h1></a>
    <a href="?page=kluis"><h1>Crack the vault</h1></a>
    <a href="?page=mystery-gift"><h1>Secret code</h1></a>

</div>
