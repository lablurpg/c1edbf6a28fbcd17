<?php
#only accessible if you are logged in
include('includes/security.php');

$page = 'account-options';
#Load good language for the page
include_once('language/language-pages.php');

#Build pages.
switch ($_GET['category']) {

    #Open in person
    case "personal":

        $persoonlijkerror = '&nbsp;';
        $username = $_POST['username'] == '' ? $gebruiker['username'] : $_POST['username'];
        $voornaam = $_POST['voornaam'] == '' ? $gebruiker['voornaam'] : $_POST['voornaam'];
        $achternaam = $_POST['achternaam'] == '' ? $gebruiker['achternaam'] : $_POST['achternaam'];
        $land = $_POST['land'] == '' ? $gebruiker['land'] : $_POST['land'];
        $teamzien = $_POST['teamzien'] == '' ? $gebruiker['teamzien'] : $_POST['teamzien'];
        $buddieszien = $_POST['buddieszien'] == '' ? $gebruiker['buddieszien'] : $_POST['buddieszien'];
        $muziekaan = $_POST['muziekaan'] == '' ? $gebruiker['muziekaan'] : $_POST['muziekaan'];
        $sneeuwaan = $_POST['sneeuwaan'] == '' ? $gebruiker['sneeuwaan'] : $_POST['sneeuwaan'];
        $badgeszien = $_POST['badgeszien'] == '' ? $gebruiker['badgeszien'] : $_POST['badgeszien'];
        $reclame = $_POST['reclame'] == '' ? $gebruiker['reclame'] : $_POST['reclame'];
        $battleScreen = $_POST['battleScreen'] == '' ? $gebruiker['battleScreen'] : $_POST['battleScreen'];
        $youtube = $_POST['youtube'];
        $dueluitnodiging = $_POST['dueluitnodiging'] == '' ? $gebruiker['dueluitnodiging'] : $_POST['dueluitnodiging'];
        $premiumtekst = '<a href="?page=area-market">' . $txt['buy_premium_here'] . '</a>';

        #When the Delete button is pressed.
        if (isset($_POST['persoonlijk'])) {

            if (strlen($voornaam > 12)) {
                $persoonlijkerror = '<div class="red">' . $txt['alert_firstname_too_long'] . '</div>';
            } elseif (strlen($achternaam > 12)) {
                $persoonlijkerror = '<div class="red">' . $txt['alert_lastname_too_long'] . '</div>';
            } elseif ($teamzien != '1' && $teamzien != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_seeteam_invalid'] . '</div>';
            } elseif ($badgeszien != '1' && $badgeszien != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_seebadges_invalid'] . '</div>';
            } elseif ($dueluitnodiging != '1' && $dueluitnodiging != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_duel_invalid'] . '</div>';
            } elseif ($buddieszien != '1' && $buddieszien != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_seebuddies_invalid'] . '</div>';
            } elseif ($sneeuwaan != '1' && $sneeuwaan != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_seesnow_invalid'] . '</div>';
            } elseif ($reclame != '1' && $reclame != '0') {
                $persoonlijkerror = '<div class="red">' . $txt['alert_advertisement_invalid'] . '</div>';
            } else {
                if ($youtube) {
                    $youtubeURL = getYoutubeID($youtube);
                } else {
                    $youtubeURL = '';
                }
                if ($reclame == 1) {
                    #Saving data
                    mysql_query("UPDATE `gebruikers` 
                        SET `voornaam`='" . $voornaam . "', 
                        `achternaam`='" . $achternaam . "', 
                        `youtube`='" . $youtubeURL . "', 
                        `land`='" . $land . "',  
                        `buddieszien`='" . $buddieszien . "', 
                        `teamzien`='" . $teamzien . "', 
                        `muziekaan`='" . $muziekaan . "', 
                        `badgeszien`='" . $badgeszien . "', 
                        `dueluitnodiging`='" . $dueluitnodiging . "', 
                        `battleScreen`='" . $battleScreen . "', 
                        `reclame`='" . $reclame . "', 
                        `reclameAanSinds`= NOW(), 
                        `sneeuwaan`='" . $sneeuwaan . "' 
                        WHERE `user_id`='" . $_SESSION['id'] . "'");
                } else {
                    #Saving data
                    mysql_query("UPDATE `gebruikers` 
                        SET `voornaam`='" . $voornaam . "', 
                        `achternaam`='" . $achternaam . "', 
                        `youtube`='" . $youtubeURL . "', 
                        `land`='" . $land . "',  
                        `buddieszien`='" . $buddieszien . "', 
                        `teamzien`='" . $teamzien . "', 
                        `muziekaan`='" . $muziekaan . "', 
                        `badgeszien`='" . $badgeszien . "', 
                        `reclame`='0',
                        `reclameAanSinds`=NOW(),
                        `dueluitnodiging`='" . $dueluitnodiging . "', 
                        `battleScreen`='" . $battleScreen . "', 
                        `sneeuwaan`='" . $sneeuwaan . "' 
                        WHERE `user_id`='" . $_SESSION['id'] . "'");
                }

                #Display on-screen notification that it was successful
                $persoonlijkerror = '<div class="green">' . $txt['success_modified'] . '</div>';
                refresh(3, "?page=account-options&category=personal");
            }

            #Fix Username FF
            if ($username != $gebruiker['username']) {
                if ($gebruiker['gold'] < 15) {
                    $persoonlijkerror = '<div class="red">' . $txt['alert_not_enough_gold'] . '</div>';
                } elseif (empty($username)) {
                    $persoonlijkerror = '<div class="red">' . $txt['alert_no_username'] . '</div>';
                } elseif (strlen($username) < 3) {
                    $persoonlijkerror = '<div class="red">' . $txt['alert_username_too_short'] . '</div>';
                } elseif (strlen($username > 10)) {
                    $persoonlijkerror = '<div class="red">' . $txt['alert_username_too_long'] . '</div>';
                } elseif (mysql_num_rows(mysql_query("SELECT `username` FROM `gebruikers` WHERE `username`='" . $username . "'")) >= "1") {
                    $persoonlijkerror = '<div class="red">' . $txt['alert_username_already_taken'] . '</div>';
                } else {
                    #Saving data
                    mysql_query("UPDATE `gebruikers` SET `username`='" . $username . "', `gold`=`gold`-'15' WHERE `user_id`='" . $_SESSION['id'] . "'");
                    mysql_query("UPDATE `ban` SET `gebruiker`='" . $username . "' WHERE `gebruiker`='" . $gebruiker['username'] . "'");
                    mysql_query("UPDATE `ban` SET `banned`='" . $username . "' WHERE `banned`='" . $gebruiker['username'] . "'");

                    $persoonlijkerror = '<div class="green">' . $txt['success_modified'] . '</div>';
                }
            }
        }

        #Watch if player has premium account
        if ($gebruiker['premiumaccount'] >= 1) $premiumtekst = '' . $gebruiker['premiumaccount'] . ' ' . $txt['days_left'];
        ?>

        <form method="post">
            <?php if (isset($_POST['persoonlijk'])) echo $persoonlijkerror; ?>
            <center>
                <table width="400" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="200" height="25"><?php echo $txt['premium_days']; ?></td>
                        <td width="200"><? echo $premiumtekst; ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['username']; ?></td>
                        <td><input type="text" name="username" class="text_long" value="<? echo $username; ?>"
                                   maxlength="10"/><img src="images/icons/gold.png"
                                                        title="<?php echo $txt['cost_15_gold']; ?>"
                                                        style="margin:0px 0px -3px 5px;"/> 15
                        </td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['firstname']; ?></td>
                        <td><input type="text" name="voornaam" class="text_long" value="<? echo $voornaam; ?>"
                                   maxlength="12"/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['lastname']; ?></td>
                        <td><input type="text" name="achternaam" class="text_long" value="<? echo $achternaam; ?>"
                                   maxlength="12"/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['country']; ?></td>
                        <td><select name="land" class="text_select">
                                <?
                                $landsql = mysql_query("SELECT `en`, `nl` FROM `landen` ORDER BY `" . $lang['taalshort'] . "` ASC");

                                if (isset($land)) $landd = $land;
                                else $landd = $gebruiker['land'];

                                while ($land = mysql_fetch_array($landsql)) {
                                    $selected = '';
                                    if ($land['nl'] == $landd) $selected = 'selected';

                                    echo '<option value="' . $land['nl'] . '" ' . $selected . '>' . $land['nl'] . '</option>';
                                }
                                ?>
                            </select></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['youtube']; ?></td>
                        <td><input type="text" name="youtube" class="text_long" value="<? if ($gebruiker['youtube']) {
                                echo 'https://www.youtube.com/watch?v=' . $gebruiker['youtube'];
                            }; ?>"/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['team_on_profile']; ?></td>
                        <td><?php
                            if ($teamzien == 1) {
                                echo '<input type="radio" name="teamzien" value="1" id="ja" checked /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="teamzien" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } elseif ($teamzien == 0) {
                                echo '<input type="radio" name="teamzien" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="teamzien" value="0" id="nee" checked /><label> ' . $txt['no'] . '</label>';
                            } #If there is no team yet
                            else {
                                echo '<input type="radio" name="teamzien" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="teamzien" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['buddies_on_profile']; ?></td>
                        <td><?php
                            if ($buddieszien == 1) {
                                echo '<input type="radio" name="buddieszien" value="1" id="ja" checked /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="buddieszien" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } elseif ($buddieszien == 0) {
                                echo '<input type="radio" name="buddieszien" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="buddieszien" value="0" id="nee" checked /><label> ' . $txt['no'] . '</label>';
                            } #If there is no buddieseen yet
                            else {
                                echo '<input type="radio" name="buddieszien" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="buddieszien" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['snow_on']; ?></td>
                        <td><?php
                            if ($sneeuwaan == 1) {
                                echo '<input type="radio" name="sneeuwaan" value="1" id="ja" checked /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="sneeuwaan" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } elseif ($sneeuwaan == 0) {
                                echo '<input type="radio" name="sneeuwaan" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="sneeuwaan" value="0" id="nee" checked /><label> ' . $txt['no'] . '</label>';
                            } #If there is no snow yet
                            else {
                                echo '<input type="radio" name="sneeuwaan" value="1" id="ja" /><label style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                        <input type="radio" name="sneeuwaan" value="0" id="nee" /><label> ' . $txt['no'] . '</label>';
                            } ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['badges_on_profile']; ?></td>
                        <td><?php
                            if ($gebruiker['Badge case'] == 0) {
                                echo $txt['alert_dont_have_badgebox'];
                            } else {

                                if ($badgeszien == 1) {
                                    echo '<input type="radio" name="badgeszien" value="1" id="badges1" checked /><label for="badges1" style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                            <input type="radio" name="badgeszien" value="0" id="badges2" /><label for="badges2"> ' . $txt['no'] . '</label>';
                                } elseif ($badgeszien == 0) {
                                    echo '<input type="radio" name="badgeszien" value="1" id="badges1" /><label for="badges1" style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                            <input type="radio" name="badgeszien" value="0" id="badges2" checked /><label for="badges2"> ' . $txt['no'] . '</label>';
                                } #If there is no team yet
                                else {
                                    echo '<input type="radio" name="badgeszien" value="1" id="badges1" /><label for="badges1" style="padding-right:17px"> ' . $txt['yes'] . '</label>
                                            <input type="radio" name="badgeszien" value="0" id="badges2" /><label for="badges2"> ' . $txt['no'] . '</label>';
                                }
                            } ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['music_on']; ?></td>
                        <td><?php
                            if ($muziekaan == 1) {
                                echo '<input type="radio" name="muziekaan" value="1" id="ja" checked /><label style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="muziekaan" value="0" id="nee" /><label> ' . $txt['off'] . '</label>';
                            } elseif ($muziekaan == 0) {
                                echo '<input type="radio" name="muziekaan" value="1" id="ja" /><label style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="muziekaan" value="0" id="nee" checked /><label> ' . $txt['off'] . '</label>';
                            } #If there is no music on yet
                            else {
                                echo '<input type="radio" name="muziekaan" value="1" id="ja" /><label style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="muziekaan" value="0" id="nee" /><label> ' . $txt['off'] . '</label>';
                            } ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['duel_invitation']; ?></td>
                        <td><?php

                            if ($dueluitnodiging == 1) {
                                echo '<input type="radio" name="dueluitnodiging" value="1" id="duel1" checked /><label for="duel1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="dueluitnodiging" value="0" id="duel2" /><label for="duel2"> ' . $txt['off'] . '</label>';
                            } elseif ($dueluitnodiging == 0) {
                                echo '<input type="radio" name="dueluitnodiging" value="1" id="duel1" /><label for="duel1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="dueluitnodiging" value="0" id="duel2" checked /><label for="duel2"> ' . $txt['off'] . '</label>';
                            } #If there is no duel invitation yet
                            else {
                                echo '<input type="radio" name="dueluitnodiging" value="1" id="duel1" /><label for="duel1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="dueluitnodiging" value="0" id="duel2" /><label for="duel2"> ' . $txt['off'] . '</label>';
                            }
                            ?></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['advertisement']; ?></td>
                        <td><?php

                            if ($reclame == 1) {
                                echo '<input type="radio" name="reclame" value="1" id="reclame1" checked /><label for="reclame1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                    <input type="radio" name="reclame" value="0" id="reclame2" /><label for="reclame2"> ' . $txt['off'] . '</label>';
                            } elseif ($reclame == 0) {
                                echo '<input type="radio" name="reclame" value="1" id="reclame1" /><label for="reclame1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="reclame" value="0" id="reclame2" checked /><label for="reclame2"> ' . $txt['off'] . '</label>';
                            } #If there is no advertising yet
                            else {
                                echo '<input type="radio" name="reclame" value="1" id="reclame1" /><label for="reclame1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                        <input type="radio" name="reclame" value="0" id="reclame2" /><label for="reclame2"> ' . $txt['off'] . '</label>';
                            }
                            ?><? if ($reclame == 1 AND (24 * 3600) + $gebruiker['reclameAanSinds'] >= time()) {
                                echo '<span style="color:orangered;"><b><small>Active in 24h</small></b></span>';
                            } elseif ($reclame == 1) {
                                echo '<span style="color:green;"><b><small>Active since ' . date("d-m-Y", $gebruiker[reclameAanSinds]) . '</small></b></span>';
                            } ?></td>
                    </tr>
                    <tr>
                        <td colspan="2"><b><?php echo $txt['advertisement_info']; ?></b><br/><br/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['battleScreen']; ?></td>
                        <td><?php

                            if ($battleScreen == 1) {
                                echo '<input type="radio" name="battleScreen" value="1" id="battleScreen1" checked /><label for="battleScreen1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                    <input type="radio" name="battleScreen" value="0" id="battleScreen2" /><label for="battleScreen2"> ' . $txt['off'] . '</label>';
                            } elseif ($battleScreen == 0) {
                                echo '<input type="radio" name="battleScreen" value="1" id="battleScreen1" /><label for="battleScreen1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                    <input type="radio" name="battleScreen" value="0" id="battleScreen2" checked /><label for="battleScreen2"> ' . $txt['off'] . '</label>';
                            } #If there is no battleScreen yet
                            else {
                                echo '<input type="radio" name="battleScreen" value="1" id="battleScreen1" /><label for="battleScreen1" style="padding-right:8px"> ' . $txt['on'] . '</label>
                                    <input type="radio" name="battleScreen" value="0" id="battleScreen2" /><label for="battleScreen2"> ' . $txt['off'] . '</label>';
                            }
                            ?></td>
                    </tr>
                    <tr>
                        <td height="25">&nbsp;</td>
                        <td>
                            <button type="submit" name="persoonlijk"
                                    class="button"><?php echo $txt['button_personal']; ?></button>
                        </td>
                    </tr>
                </table>
            </center>
        </form>

        <?
        #Close personally
        break;

    #Open password
    case "password":

        #when the delete button is pressed
        if (isset($_POST['veranderww'])) {

            #Check if something has been entered
            if (empty($_POST['wachtwoordwachtwoordaanmeld']) && empty($_POST['huidig']) && empty($_POST['wachtwoordcontrole']))
                $wachtwoordtekst = '<div class="red">' . $txt['alert_all_fields_required'] . '</div>';
            #the current password is not the same as the new password entered
            elseif ($_POST['huidig'] == $_POST['wachtwoordwachtwoordaanmeld'])
                $wachtwoordtekst = '<div class="red">' . $txt['alert_old_new_password_thesame'] . '</div>';
            #Is the current password correct?
            elseif (MD5($_POST['huidig']) <> $gebruiker['wachtwoord'])
                $wachtwoordtekst = '<div class="red">' . $txt['alert_old_password_wrong'] . '</div>';
            #Is the password longer than 5 characters
            elseif (strlen($_POST['wachtwoordwachtwoordaanmeld']) < 5)
                $wachtwoordtekst = '<div class="red">' . $txt['alert_password_too_short'] . '</div>';
            #Both passwords match
            elseif ($_POST['wachtwoordwachtwoordaanmeld'] <> $_POST['wachtwoordcontrole'])
                $wachtwoordtekst = '<div class="red">' . $txt['alert_new_controle_password_wrong'] . '</div>';
            else {
                $wachtwoordmd5 = md5($_POST['wachtwoordcontrole']);
                mysql_query("UPDATE `gebruikers` SET `wachtwoord`='" . $wachtwoordmd5 . "' WHERE `user_id`='" . $_SESSION['id'] . "'");
                $wachtwoordtekst = '<div class="green">' . $txt['success_password'] . '</div>';
            }
        }

        ?>
        <form method="post">
            <?php if (isset($_POST['veranderww'])) echo $wachtwoordtekst; ?>
            <center>
                <table width="350" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="200" height="25"><?php echo $txt['new_password']; ?></td>
                        <td width="150"><input type="password" name="wachtwoordwachtwoordaanmeld" class="text_long"/>
                        </td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['new_password_again']; ?></td>
                        <td><input type="password" name="wachtwoordcontrole" class="text_long"/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['password_now']; ?></td>
                        <td><input type="password" name="huidig" class="text_long"/></td>
                    </tr>
                    <tr>
                        <td height="25">&nbsp;</td>
                        <td>
                            <button type="submit" name="veranderww"
                                    class="button"><?php echo $txt['button_password']; ?></button>
                        </td>
                    </tr>
                </table>
            </center>
        </form>
        <?

        #close password
        break;
    #Open profile
    case "profile":
        #When the Button is pressed
        if (isset($_POST['profiel'])) {
            #Format text

            $dirty_html_tekst = $_POST['tekst'];
            require_once 'includes/htmlpurifier/library/HTMLPurifier.auto.php';

            $config = HTMLPurifier_Config::createDefault();
            $purifier = new HTMLPurifier($config);
            $tekst = $purifier->purify($dirty_html_tekst);

            mysql_query("UPDATE `gebruikers` SET `profiel`='" . $tekst . "' WHERE `user_id`='" . $_SESSION['id'] . "'");
            $profieltekst = '<div class="green">' . $txt['success_profile'] . '</div>';
        }

        $tekst = mysql_fetch_array(mysql_query("SELECT `profiel` FROM `gebruikers` WHERE `user_id`='" . $_SESSION['id'] . "'"));
        /*$tekst = htmlspecialchars_decode($ptekst['profiel']);
        $tekst = eregi_replace("\[remove]","",$tekst);*/

        ?>

        <link href="includes/summernote/bootstrap.css" rel="stylesheet">
        <link href="includes/summernote/summernote.css" rel="stylesheet">
        <script>
            $(document).ready(function () {
                $('#summernote').summernote({
                    theme: 'yeti',
                    lang: "nl-NL",
                    callbacks: {
                        onImageUpload: function (image) {
                            uploadImage(image[0]);
                        }
                    },
                    toolbar: [
                        ['style', ['style']],
                        ['font', ['bold', 'italic', 'underline', 'clear']],
                        ['fontname', ['fontname']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['height', ['height']],
                        ['table', ['table']],
                        ['insert', ['link', 'picture', 'video', 'hr']],
                        ['view', ['fullscreen']]
                    ]
                });

                function uploadImage(image) {
                    var data = new FormData();
                    data.append("image", image);
                    $.ajax({
                        data: data,
                        type: "POST",
                        url: "upload-image.php",
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (url) {
                            /* $('.summernote').summernote('insertImage', url);*/
                            $('#summernote').summernote('insertImage', url, function ($image) {
                                $image.css('width', $image.width() / 3);
                                $image.attr('data-filename', 'retriever');
                            });
                            //console.log(url);
                        },
                        error: function (data) {
                            console.log(data);
                        }
                    });
                }

            });
        </script>

        <form method="post" enctype="multipart/form-data">
            <?php if (isset($_POST['profiel'])) echo $profieltekst; ?>
            <center>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td><textarea id="summernote" rows="12" name="tekst"
                                      style="width: 100%;"><? echo $tekst['profiel']; ?></textarea></td>
                    </tr>
                    <tr>
                        <td height="25"><br/>
                            <button type="submit" name="profiel"
                                    class="button"><?php echo $txt['button_profile']; ?></button>
                        </td>
                    </tr>
                </table>
            </center>
        </form>

        <?
        #change profile close
        break;

    #Open new
    case "restart":

        if (isset($_POST['opnieuw'])) {
            if (empty($_POST['wachtwoord']))
                $opnieuwtekst = '<div class="red">' . $txt['alert_no_password'] . '</div>';
            elseif (md5($_POST['wachtwoord']) != $gebruiker['wachtwoord'])
                $opnieuwtekst = '<div class="red">' . $txt['alert_password_wrong'] . '</div>';
            elseif ($_POST['wereld'] == "")
                $opnieuwtekst = '<div class="red">' . $txt['alert_no_beginworld'] . '</div>';

            elseif ($_POST['wereld'] != 'Kanto' && $_POST['wereld'] != 'Johto' && $_POST['wereld'] != 'Hoenn' && $_POST['wereld'] != 'Sinnoh' && $_POST['wereld'] != 'Unova' && $_POST['wereld'] != 'Kalos')
                $opnieuwtekst = '<div class="red">' . $txt['alert_world_invalid'] . '</div>';
            else {
                $datum = date('Y-m-d H:i:s');
                #All items gone!
                mysql_query("UPDATE `gebruikers_item` SET `itembox`='Bag', `Badge case`='', `Poke ball`='', `Great ball`='', `Ultra ball`='', `Premier ball`='', `Net ball`='', `Dive ball`='', `Nest ball`='', `Repeat ball`='', `Timer ball`='', `Master ball`='', `Potion`='', `Super potion`='', `Hyper potion`='', `Full heal`='', `Revive`='', `Max revive`='', `Pokedex`='', `Pokedex chip`='', `Fishing rod`='', `Cave suit`='', `Protein`='', `Iron`='', `Carbos`='', `Calcium`='', `HP up`='', `Rare candy`='', `Duskstone`='', `Firestone`='', `Leafstone`='', `Moonstone`='', `Ovalstone`='', `Shinystone`='', `Sunstone`='', `Thunderstone`='', `Waterstone`='' , `Dawnstone`='' WHERE `user_id`='" . $_SESSION['id'] . "'");
                #All badges gone!
                mysql_query("UPDATE `gebruikers_badges` SET `Boulder`='0', `Cascade`='0', `Thunder`='0', `Rainbow`='0', `Marsh`='0', `Soul`='0', `Volcano`='0', `Earth`='0', `Zephyr`='0', `Hive`='0', `Plain`='0', `Fog`='0', `Storm`='0', `Mineral`='0', `Glacier`='0', `Rising`='0', `Stone`='0', `Knuckle`='0', `Dynamo`='0', `Heat`='0', `Balance`='0', `Feather`='0', `Mind`='0', `Rain`='0', `Coal`='0', `Forest`='0', `Cobble`='0', `Fen`='0', `Relic`='0', `Mine`='0', `Icicle`='0', `Beacon`='0', `Trio`='0', `Basic`='0', `Insect`='0', `Bolt`='0', `Quake`='0', `Jet`='0', `Freeze`='0', `Legend`='0' WHERE `user_id`='" . $_SESSION['id'] . "'");

                #All tmhm gone!
                mysql_query("UPDATE `gebruikers_tmhm` SET `TM01`='0', `TM02`='0', `TM03`='0', `TM04`='0', `TM05`='0', `TM06`='0', `TM07`='0', `TM08`='0', `TM09`='0', `TM10`='0', `TM11`='0', `TM12`='0', `TM13`='0', `TM14`='0', `TM15`='0', `TM16`='0', `TM17`='0', `TM18`='0', `TM19`='0', `TM20`='0', `TM21`='0', `TM22`='0', `TM23`='0', `TM24`='0', `TM25`='0', `TM26`='0', `TM27`='0', `TM28`='0', `TM29`='0', `TM30`='0', `TM31`='0', `TM32`='0', `TM33`='0', `TM34`='0', `TM35`='0', `TM36`='0', `TM37`='0', `TM38`='0', `TM39`='0', `TM40`='0', `TM41`='0', `TM41`='0', `TM42`='0', `TM43`='', `TM44`='0', `TM45`='0', `TM46`='0', `TM47`='0', `TM48`='0', `TM49`='0', `TM50`='0', `TM51`='0', `TM52`='0', `TM53`='0', `TM54`='0', `TM55`='0', `TM56`='0', `TM57`='0', `TM58`='0', `TM59`='0', `TM60`='0', `TM61`='0', `TM62`='0', `TM63`='0', `TM64`='0', `TM65`='0', `TM66`='0', `TM67`='0', `TM68`='0', `TM69`='0', `TM70`='0', `TM71`='0', `TM72`='0', `TM73`='0', `TM74`='0', `TM75`='0', `TM76`='0', `TM77`='0', `TM78`='0', `TM79`='0', `TM80`='0', `TM81`='0', `TM82`='0', `TM83`='0', `TM84`='0', `TM85`='0', `TM86`='', `TM87`='0', `TM88`='0', `TM89`='0', `TM90`='0', `TM91`='0', `TM92`='0', `HM01`='0', `HM02`='0', `HM03`='0', `HM04`='0', `HM05`='0', `HM06`='0', `HM07`='0', `HM08`='0' WHERE `user_id`='" . $_SESSION['id'] . "'");

                #Many users are getting rid of it!
                mysql_query("UPDATE `gebruikers` SET `datum`='" . $datum . "', `wereld`='" . $_POST['wereld'] . "', `silver`='75', `bank`='', `storten`='3', `huis`='doos', `geluksrad`='1', `rank`='1', `rankexp`='0', `rankexpnodig`='245', `aantalpokemon`='0', `badges`='0', `captcha_tevaak_fout`='0', `werkervaring`='0', `gewonnen`='0', `verloren`='0', `eigekregen`='0', `lvl_choose`='', `wiequiz`='0000-00-00 00:00:00', `werktijd`='0', `pokecentertijd`='0', `gevangenistijd`='0', `geluksrad`='3', `races_winst`='3', `races_verlies`='3', `pok_gezien`='', `pok_bezit`='', `pok_gehad`='' WHERE `user_id`='" . $_SESSION['id'] . "'");
                #All Pokemons gone!
                mysql_query("DELETE FROM `pokemon_speler` WHERE `user_id`='" . $_SESSION['id'] . "'");
                #Transfer list Empty!
                mysql_query("DELETE FROM `transferlijst` WHERE `user_id`='" . $_SESSION['id'] . "'");
                #Daycare Empty!
                mysql_query("DELETE FROM `daycare` WHERE `user_id`='" . $_SESSION['id'] . "'");
                #Events empty!
                mysql_query("DELETE FROM `gebeurtenissen` WHERE `ontvanger_id`='" . $_SESSION['id'] . "'");
                $opnieuwtekst = '<div class="green">' . $txt['success_restart'] . '</div>';
            }
        }

        if (isset($_POST['opnieuw'])) echo $opnieuwtekst; ?>
        <center>
            <table width="660" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td><?php echo $txt['restart_title_text']; ?></td>
                </tr>
            </table>

            <form method="post">
                <table width="350" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td width="200" height="25"><?php echo $txt['password_security']; ?></td>
                        <td width="150"><input type="password" name="wachtwoord" class="text_long" value=""/></td>
                    </tr>
                    <tr>
                        <td height="25"><?php echo $txt['beginworld']; ?></td>
                        <td><input type="radio" name="wereld" id="kanto"
                                   value="Kanto" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Kanto") {
                                echo " checked='checked'";
                            } ?>> <label for="kanto">Kanto</label></td>
                    </tr>
                    <tr>
                        <td rowspan="5"></td>
                        <td height="25"><input type="radio" name="wereld" id="johto"
                                               value="Johto" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Johto") {
                                echo " checked='checked'";
                            } ?>> <label for="johto">Johto</label></td>
                    </tr>
                    <tr>
                        <td height="25"><input type="radio" name="wereld" id="hoenn"
                                               value="Hoenn" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Hoenn") {
                                echo " checked='checked'";
                            } ?>> <label for="hoenn">Hoenn</label></td>
                    </tr>
                    <tr>
                        <td height="25"><input type="radio" name="wereld" id="sinnoh"
                                               value="Sinnoh" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Sinnoh") {
                                echo " checked='checked'";
                            } ?>> <label for="sinnoh">Sinnoh</label></td>
                    </tr>
                    <tr>
                        <td height="25"><input type="radio" name="wereld" id="unova"
                                               value="Unova" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Unova") {
                                echo " checked='checked'";
                            } ?>> <label for="unova">Unova</label></td>
                    </tr>
                    <tr>
                        <td height="25"><input type="radio" name="wereld" id="kalos"
                                               value="Kalos" <?php if (isset($_POST['wereld']) && $_POST['wereld'] == "Kalos") {
                                echo " checked='checked'";
                            } ?>> <label for="kalos">Kalos</label></td>
                    </tr>
                    <tr>
                        <td>
                            <button type="submit" name="opnieuw"
                                    class="button"><?php echo $txt['button_restart']; ?></button>
                        </td>
                    </tr>
                </table>
            </form>
        </center>
        <?
        #Close profile
        break;

    #Close profile
    case "picture":

        ?>

        <h2>Upload new profile picture</h2>
        <br/>
        <img src="<?= $gebruiker['profielfoto'] ?>" alt="" title="" style="max-width: 130px;"><br/><br/>
        <form action="?page=upload-profile&do=upload" method="post" enctype="multipart/form-data">
            <input name="image_max_width" type="hidden" id="hiddenField" value="400"/>
            Profile picture:
            <input type="file" name="image" size="20"/><br/>
            Max size: 2 MB.<br/>Extensions that are allowed: jpg, jpeg, gif, png.<br/>
            <button type="submit" name="submit" class="button pull-right">Upload</button>
            <br/><br/>
        </form>

        <br><br>

        <h2>Upload new cover</h2>
        <br/>
        <img src="<?= $gebruiker['cover'] ?>" alt="" title="" style="max-width: 330px;"><br/><br/>
        <form action="?page=upload-cover&do=upload" method="post" enctype="multipart/form-data">
            <input name="image_max_width" type="hidden" id="hiddenField" value="400"/>
            Cover:
            <input type="file" name="image" size="20"/><br/>
            Max size: 2 MB.<br/>Extensions that are allowed: jpg, jpeg, gif, png.<br/>
            <button type="submit" name="submit" class="button pull-right">Upload</button>
            <br/><br/>
        </form>

        <?
        #Close picture
        break;

    #standard 
    default:
        #Forward to personal
        header("Location: ?page=account-options&category=personal");
        break;
}
?>