<div class="title">
<h1><i class="fas fa-key"></i><center> Account Security</center></h1>
</div>
			
<div class="infobox pgs">
<h2>Do Not Get Phished</h2>
<p>Phishing is when someone creates a site or login page to look like that of a legitimate one to get your password. See <a href="https://en.wikipedia.org/wiki/Phishing">Phishing (Wikipedia)</a> to learn more about it.</p>

<p>One basic thing to watch for is to make sure the domain name is lablurpg.com. <br>Here are some examples (those marked green are safe, and those marked red are unsafe).</p>

<div style="color:green">https://<b>www.lablurpg.com</b></div>
<div style="color:red">http://boguslablurpg.weebly.com/login</div>
<div style="color:red">http://example.com/lablurpg.com/login.php</div>
<div style="color:red">http://example.com/lablurpg/login.html</div>
</div>
<div class="infobox pgs">
<h2>Don't Fall For "Cheats" and Scams</h2>
<p><b>There are no cheats</b> in the game. If someone tells you they know cheats to get you rare stuff, they're just trying to get access to your account by fooling you.</p>

<p>Please note that setting your email on your profile lets you recover the account in case you forget your password. And entering someone else's email address lets that person take control of your account. <br>So please do not enter any email address on your account that you do not own.</p>

<p>Never give someone else your password, no matter who they say they are. <b>Administrators will never need your password</b> for any reason. You will also not be contacted by us regarding contests or tournaments.</p>

<p>If someone tells you to download something to help with the game, do not download it. It could be a virus/spyware that can steal your login information. Always have an anti-spyware/anti-virus installed on your PC and never install any software when you don't know exactly what it does.</p>
</div>
<div class="infobox pgs">
<h2>Use A Strong Password</h2>
<p>Try to use a hard-to-guess password. Never use the following as your password:
</p><ul>
	<li>Names of people around you</li>
	<li>Your favorite personalities</li>
	<li>Phone numbers</li>
	<li>Simply using adjacent keys on the keyboard: ones like 123456, qwerty*, asdfgh*</li>
	<li>Pokémon names</li>
</ul>

<p>Using uncommon phrases or short sentences might be a good idea.</p>

<p>Finally, <b>do not ever use the same password for both your lablurpg account and email address account</b>. It is recommended to have a different password for every website you visit, but your email should always have its own unique password.</p>

<p><a class="infobox pgs" href="https://gmailblog.blogspot.com/2009/10/choosing-smart-password.html">Choosing A Strong Password by Gmail Blog</a>
<br><a class="infobox pgs" href="https://en.wikipedia.org/wiki/Password_strength#Guidelines_for_strong_passwords">Guidelines for Strong Passwords by Wikipedia</a>
</p>
</div>
<div class="infobox pgs">
<h2>Be careful using computers or devices not belonging to you</h2>
<p>Remember to click <b>LOGOUT</b> (drop-down from your general menu in the upper left corner) when you finish playing, especially if you are playing from an internet cafe or on someone else's computer. This is because your session may not end as soon as you leave the site. This applies to any website that makes you log in to access their services.</p>

<p>It is a good habit to <a href="https://www.google.com/support/accounts/bin/answer.py?hl=en&amp;answer=32050">Clear Cookies</a> after browsing from a public computer.</p>

<p>You can also use a browser's <a href="https://www.howtogeek.com/269265/how-to-enable-private-browsing-on-any-web-browser/">Private Browsing or Incognito mode</a> to close a session on browser close</p>
</div>
<div class="infobox pgs">
<h2>Don't Share Accounts</h2>
<p>Sharing accounts is highly frowned upon and an easy way to have your pokemon stolen. If you share an account, don't be surprised if you cannot access it later.</p>
</div>
<div class="infobox pgs">
<h2>Viruses/Spyware</h2>
<p>Please install a good anti-virus/anti-spyware on your PC, especially if you're using the Windows Operating System. Always keep it up-to-date and scan your PC regularly.</p>

<p>Do not accept files from strangers on IMs (IE: MSN, Yahoo Messenger), or anywhere for that matter, and don't click on any untrusted links they give either. Such links may persuade you to download and install programs that can record your passwords and send it to them.</p>
</div>		