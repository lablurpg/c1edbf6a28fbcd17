<?		
//Load script so you can never load page outside of the index
include("includes/security.php");

//Admin control
if($gebruiker['admin'] < 3) header('location: index.php?page=home');

?>
<form method="post">
<table width="150" border="0">
	<tr>
    	<td>Everybody</td>
        <td><input type="radio" name="ontvanger" value="allemaal" onChange=this.form.submit();></td>
    </tr>
</table>	
</form>
<?

//When the send button is pressed
if(isset($_POST['verstuur'])){
  //See who it is addressed to.
  if($_POST['ontvanger'] == "persoon"){
    //Assign name easily
    $bericht   = $_POST['tekst'];
    $ontvanger = $_POST['speler'];
    $onderwerp = $_POST['onderwerp'];
    //If no message has been typed
    if(empty($bericht)) {
      echo '<div class="red"><img src="images/icons/red.png"> No text entered.</div>';
    }
    //If no recipient is entered
    elseif(empty($ontvanger)){
      echo '<div class="red"><img src="images/icons/red.png"> No receiver entered.</div>';
    }
    elseif(!preg_match('/[A-Za-z0-9_]+$/',$onderwerp)) {
      echo '<div class="red"><img src="images/icons/red.png"> The topic may not contain those characters.</div>';
    }
    //When everything is filled in send the message
    else{
      //If no subject is entered, assign a subject
      if(empty($onderwerp)){
        $onderwerp =  "(Geen)";
      } 
      //Put in the database
      //Request time.
      $datum      = date('Y-m-d H:i:s');
      $verstuurd  = date('d-m-y H:i');
      //Remove spaces
      mysql_query("INSERT INTO `berichten` (`datum`, `ontvanger_id`, `afzender_id`, `bericht`, `onderwerp`, `gelezen`) 
        VALUES ('".$datum."', '".$ontvanger."', '1', '".$bericht."', '".$onderwerp."', '".$verstuurd."', 'nee')");
      echo '<div class="green"><img src="images/icons/green.png"> Message was sent successfully!</div>';
    }      
  }
  else{
    //Assign name easily
    $bericht   = $_POST['tekst'];
    $onderwerp = $_POST['onderwerp'];
    //If no message has been typed
    if(empty($bericht)) {
      echo '<div class="red"><img src="images/icons/red.png"> No text entered.</div>';
    }
    elseif(!preg_match('/[A-Za-z0-9_]+$/',$onderwerp)) {
      echo '<div class="red"><img src="images/icons/red.png"> The subject must not contain any characters.</div>';
    }
    //When everything is filled in send the message
    else{
      $speler = mysql_query("SELECT `user_id` FROM `gebruikers`");
      while($spelers = mysql_fetch_array($speler)){
        //If no subject is entered, assign a subject
        if(empty($onderwerp)){
          $onderwerp =  "(Geen)";
        } 
        //Put in the database
        //Request time.
        $datum      = date('Y-m-d H:i:s');
        mysql_query("INSERT INTO `berichten` (`datum`, `ontvanger_id`, `afzender_id`, `bericht`, `onderwerp`, `gelezen`) 
          VALUES ('".$datum."', '".$spelers['user_id']."', '1', '".$bericht."', '".$onderwerp."', 'nee')");
      }
    echo '<div class="green"><img src="images/icons/green.png"> Mass message sent successfully.</div>';  
    }
  }

}

//If something is chosen
if(isset($_POST['ontvanger'])){
  echo '<form method="post">
  			<table width="600" border="0">';
    if($_POST['ontvanger'] == "persoon"){
      echo '<tr>
	  			<td>Receiver:</td>
				<td><input type="text" name="speler" class="text_long" value="'.$_POST['speler'].'"></td>
			</tr>';
    }
      echo '<tr>
				<td width="110">Topic:</td>
				<td width="490"><input type="text" name="onderwerp" class="text_long" value="Daily Reset"></td>
			</tr>
    		<tr>
				<td colspan="2"><textarea style="width:580px;" class="text_area" rows="15"  name="tekst">'.$_POST['tekst'].'</textarea></td>
			</tr>
			<tr>
				<td colspan="2"><input type="hidden" value="'.$_POST['ontvanger'].'" name="ontvanger">
					<input type="submit" value="Send" name="verstuur" class="button"></td>
			</tr>
		</table>
  		</form>';
}
?>