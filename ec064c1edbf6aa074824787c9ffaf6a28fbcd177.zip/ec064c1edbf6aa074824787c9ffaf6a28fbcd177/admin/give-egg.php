<?		
//Load script so you can never load page outside of the index
include("includes/security.php");

//Admin control
if($gebruiker['admin'] < 2) header('location: index.php?page=home');

#####################################################################


if(isset($_POST['submit'])) {
  //Assign easy name
  $user_id = $_POST['user_id'];
  $wereld = $_POST['wereld'];
  $ei     = $_POST['ei'];

  //Load data from player
  $aantal = mysql_num_rows(mysql_query("SELECT `user_id` FROM `pokemon_speler` WHERE `user_id`='".$user_id."' AND `opzak`='ja'"));

  if($user_id == '')
  	echo '<div class="red"><img src="images/icons/red.png"> No player selected.</div>';
  elseif($wereld == '')
  	echo '<div class="red"><img src="images/icons/red.png"> No world selected.</div>';
  elseif($ei == '')
  	echo '<div class="red"><img src="images/icons/red.png"> No egg chosen.</div>';
  elseif($aantal == 6)
    echo '<div class="red"><img src="images/icons/red.png"> The trainer already has 6 pokemon.</div>';
  else{
    //1 by number, because otherwise you have 2x in your pocket number 1 eg.
    $opzak_nummer = $aantal+1;
    //Start baby pokemon timer
    $tijd = date('Y-m-d H:i:s');
    //Save Pokemon
    //If the egg is a starter egg
	  if($ei == 1){ 
      //Load random pokemon, and its data
      $query = mysql_fetch_array(mysql_query("SELECT pw.wild_id, pw.naam, pw.groei, pw.attack_base, pw.defence_base, pw.speed_base, `pw`.`spc.attack_base`, `pw`.`spc.defence_base`, pw.hp_base, pw.aanval_1, pw.aanval_2, pw.aanval_3, pw.aanval_4 FROM pokemon_wild AS pw INNER JOIN pokemon_nieuw_starter AS pnb ON pw.wild_id = pnb.wild_id ORDER BY rand() LIMIT 1"));
	  
      //Put the random pokemon in the pokemon player table
      mysql_query("INSERT INTO `pokemon_speler` (`wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4`) SELECT `wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4` FROM `pokemon_wild` WHERE `wild_id`='".$query['wild_id']."'");
      //Get ID from the insert above
      $pokeid	= mysql_insert_id();
      
      //Did player get pokemon ??
      if(is_numeric($pokeid)){
        mysql_query("UPDATE `gebruikers` SET `aantalpokemon`=`aantalpokemon`+'1' WHERE `user_id`='".$user_id."'");
      }
      
      //Choose character
      $karakter  = mysql_fetch_array(mysql_query("SELECT * FROM `karakters` ORDER BY rand() limit 1"));
      
      //Needless to look up and save
      $experience = mysql_fetch_array(mysql_query("SELECT `punten` FROM `experience` WHERE `soort`='".$query['groei']."' AND `level`='6'"));
    
      //Create and save Pokemon IV
      //Iv random number between 1.31. I take 2 because 1 is too little:P
      $attack_iv       = rand(2,31);
      $defence_iv      = rand(2,31);
      $speed_iv        = rand(2,31);
      $spcattack_iv    = rand(2,31);
      $spcdefence_iv   = rand(2,31);
      $hp_iv           = rand(2,31);
    
      //Calculate stats
      $attackstat     = round((((($query['attack_base']*2+$attack_iv)*5/100)+5)*1)*$karakter['attack_add']);
      $defencestat    = round((((($query['defence_base']*2+$defence_iv)*5/100)+5)*1)*$karakter['defence_add']);
      $speedstat      = round((((($query['speed_base']*2+$speed_iv)*5/100)+5)*1)*$karakter['speed_add']);
      $spcattackstat  = round((((($query['spc.attack_base']*2+$spcattack_iv)*5/100)+5)*1)*$karakter['spc.attack_add']);
      $spcdefencestat = round((((($query['spc.defence_base']*2+$spcdefence_iv)*5/100)+5)*1)*$karakter['spc.defence_add']);
      $hpstat         = round(((($query['hp_base']*2+$hp_iv)*5/100)+5)+10);
      
      //Save all Pokemon data
      mysql_query("UPDATE `pokemon_speler` SET `level`='5', `karakter`='".$karakter['karakter_naam']."', `expnodig`='".$experience['punten']."', `user_id`='".$user_id."', `opzak`='ja', `opzak_nummer`='".$opzak_nummer."', `ei`='1', `ei_tijd`='".$tijd."', `attack_iv`='".$attack_iv."', `defence_iv`='".$defence_iv."', `speed_iv`='".$speed_iv."', `spc.attack_iv`='".$spcattack_iv."', `spc.defence_iv`='".$spcdefence_iv."', `hp_iv`='".$hp_iv."', `attack`='".$attackstat."', `defence`='".$defencestat."', `speed`='".$speedstat."', `spc.attack`='".$spcattackstat."', `spc.defence`='".$spcdefencestat."', `levenmax`='".$hpstat."', `leven`='".$hpstat."' WHERE `id`='".$pokeid."'");
    }
    //If the egg is a regular egg.
    elseif($ei == 2){
      //Load random pokemon, and its data
      $query = mysql_fetch_array(mysql_query("SELECT pw.wild_id, pw.naam, pw.groei, pw.attack_base, pw.defence_base, pw.speed_base, `pw`.`spc.attack_base`, `pw`.`spc.defence_base`, pw.hp_base, pw.aanval_1, pw.aanval_2, pw.aanval_3, pw.aanval_4 FROM pokemon_wild AS pw INNER JOIN pokemon_nieuw_normaal AS pnb ON pw.wild_id = pnb.wild_id ORDER BY rand() LIMIT 1"));
      //Put the random pokemon in the pokemon player table
      mysql_query("INSERT INTO `pokemon_speler` (`wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4`) SELECT `wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4` FROM `pokemon_wild` WHERE `wild_id`='".$query['wild_id']."'");
      //Get ID from the insert above
      $pokeid	= mysql_insert_id();
      
      //Did player get pokemon ??
      if(is_numeric($pokeid)){
        mysql_query("UPDATE `gebruikers` SET `aantalpokemon`=`aantalpokemon`+'1' WHERE `user_id`='".$user_id."'");
      }
      
      //Choose character
      $karakter  = mysql_fetch_array(mysql_query("SELECT * FROM `karakters` ORDER BY rand() limit 1"));
      
      //Needless to look up and save
      $experience = mysql_fetch_array(mysql_query("SELECT `punten` FROM `experience` WHERE `soort`='".$query['groei']."' AND `level`='6'"));
    
      //Create and save Pokemon IV
      //Iv random number between 1.31. I take 2 because 1 is too little:P
      $attack_iv       = rand(2,31);
      $defence_iv      = rand(2,31);
      $speed_iv        = rand(2,31);
      $spcattack_iv    = rand(2,31);
      $spcdefence_iv   = rand(2,31);
      $hp_iv           = rand(2,31);
    
      //Calculate stats
      $attackstat     = round((((($query['attack_base']*2+$attack_iv)*5/100)+5)*1)*$karakter['attack_add']);
      $defencestat    = round((((($query['defence_base']*2+$defence_iv)*5/100)+5)*1)*$karakter['defence_add']);
      $speedstat      = round((((($query['speed_base']*2+$speed_iv)*5/100)+5)*1)*$karakter['speed_add']);
      $spcattackstat  = round((((($query['spc.attack_base']*2+$spcattack_iv)*5/100)+5)*1)*$karakter['spc.attack_add']);
      $spcdefencestat = round((((($query['spc.defence_base']*2+$spcdefence_iv)*5/100)+5)*1)*$karakter['spc.defence_add']);
      $hpstat         = round(((($query['hp_base']*2+$hp_iv)*5/100)+5)+10);
      
      //Save all Pokemon data
      mysql_query("UPDATE `pokemon_speler` SET `level`='5', `karakter`='".$karakter['karakter_naam']."', `expnodig`='".$experience['punten']."', ``user_id`='".$user_id."', `opzak`='ja', `opzak_nummer`='".$opzak_nummer."', `ei`='1', `ei_tijd`='".$tijd."', `attack_iv`='".$attack_iv."',`defence_iv`='".$defence_iv."', `speed_iv`='".$speed_iv."', `spc.attack_iv`='".$spcattack_iv."', `spc.defence_iv`='".$spcdefence_iv."', `hp_iv`='".$hp_iv."', `attack`='".$attackstat."', `defence`='".$defencestat."', `speed`='".$speedstat."', `spc.attack`='".$spcattackstat."', `spc.defence`='".$spcdefencestat."', `levenmax`='".$hpstat."', `leven`='".$hpstat."' WHERE `id`='".$pokeid."'");
    }
    //If the egg is a baby egg
    elseif($ei == 3){
      //Load random pokemon, and its data
      $query = mysql_fetch_array(mysql_query("SELECT pw.wild_id, pw.naam, pw.groei, pw.attack_base, pw.defence_base, pw.speed_base, `pw`.`spc.attack_base`, `pw`.`spc.defence_base`, pw.hp_base, pw.aanval_1, pw.aanval_2, pw.aanval_3, pw.aanval_4 FROM pokemon_wild AS pw INNER JOIN pokemon_nieuw_baby AS pnb ON pw.wild_id = pnb.wild_id ORDER BY rand() LIMIT 1"));
      //Place the random pokemon in the pokémon player table
      mysql_query("INSERT INTO `pokemon_speler` (`wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4`) SELECT `wild_id`, `aanval_1`, `aanval_2`, `aanval_3`, `aanval_4` FROM `pokemon_wild` WHERE `wild_id`='".$query['wild_id']."'");
      //Get ID from the insert above
      $pokeid	= mysql_insert_id();
      
      //Did player get pokemon ??
      if(is_numeric($pokeid)){
        mysql_query("UPDATE `gebruikers` SET `aantalpokemon`=`aantalpokemon`+'1' WHERE `user_id`='".$user_id."'");
      }
      
      //Choose character
      $karakter  = mysql_fetch_array(mysql_query("SELECT * FROM `karakters` ORDER BY rand() limit 1"));
      
      //Needless to look up and save
      $experience = mysql_fetch_array(mysql_query("SELECT `punten` FROM `experience` WHERE `soort`='".$query['groei']."' AND `level`='6'"));
    
      //Create and save Pokemon IV
      //Iv random number between 1.31. I take 2 because 1 is too little:P
      $attack_iv       = rand(2,31);
      $defence_iv      = rand(2,31);
      $speed_iv        = rand(2,31);
      $spcattack_iv    = rand(2,31);
      $spcdefence_iv   = rand(2,31);
      $hp_iv           = rand(2,31);
    
      //Calculate stats
      $attackstat     = round((((($query['attack_base']*2+$attack_iv)*5/100)+5)*1)*$karakter['attack_add']);
      $defencestat    = round((((($query['defence_base']*2+$defence_iv)*5/100)+5)*1)*$karakter['defence_add']);
      $speedstat      = round((((($query['speed_base']*2+$speed_iv)*5/100)+5)*1)*$karakter['speed_add']);
      $spcattackstat  = round((((($query['spc.attack_base']*2+$spcattack_iv)*5/100)+5)*1)*$karakter['spc.attack_add']);
      $spcdefencestat = round((((($query['spc.defence_base']*2+$spcdefence_iv)*5/100)+5)*1)*$karakter['spc.defence_add']);
      $hpstat         = round(((($query['hp_base']*2+$hp_iv)*5/100)+5)+10);
      
      //Save all Pokemon data
      mysql_query("UPDATE `pokemon_speler` SET `level`='5', `karakter`='".$karakter['karakter_naam']."', `expnodig`='".$experience['punten']."', `user_id`='".$user_id."', `opzak`='ja', `opzak_nummer`='".$opzak_nummer."', `ei`='1', `baby_tijd`='".$tijd."', `attack_iv`='".$attack_iv."',`defence_iv`='".$defence_iv."', `speed_iv`='".$speed_iv."', `spc.attack_iv`='".$spcattack_iv."', `spc.defence_iv`='".$spcdefence_iv."', `hp_iv`='".$hp_iv."', `attack`='".$attackstat."', `defence`='".$defencestat."', `speed`='".$speedstat."', `spc.attack`='".$spcattackstat."', `spc.defence`='".$spcdefencestat."', `levenmax`='".$hpstat."', `leven`='".$hpstat."' WHERE `id`='".$pokeid."'");
    }
   echo '<div class="green"><img src="images/icons/green.png"> You have '.$_POST['speler'].' successfully gave a pokemon egg.</div>';      
  }
}
?>



<center>
<form method="post">

<p>You can give someone a Pokemon egg.<br />
*Please note, if someone already has 6 Pokemon with them do not use this!</p>
<table width="250">
  <tr>
    	<td width="100"><strong>User ID:</strong></td>
    <td width="150"><input name="user_id" class="text_long" type="text" value="<?php if($_GET['player'] == '') echo $_POST['user_id']; else echo $_GET['player']; ?>"></td>
    </tr>
  <tr>
    <td rowspan="10">&nbsp;</td>
    <td height="35"><strong>Egg choice:</strong></td>
    </tr>
  <tr>
    <td><input type="radio" name="ei" value="1" id="starter" /> <label for="starter">Starter Egg</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="ei" value="2" id="gewoon" /> <label for="gewoon">Simple Egg</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="ei" value="3" id="baby" /> <label for="baby">Baby Egg</label></td>
    </tr>
  <tr>
    <td height="35"><strong>World:</strong></td>
    </tr>
  <tr>
    <td><input type="radio" name="wereld" value="Kanto" id="kanto" /> <label for="kanto">Kanto</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="wereld" value="Johto" id="johto" /> <label for="johto">Johto</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="wereld" value="Hoenn" id="hoenn" /> <label for="hoenn">Hoenn</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="wereld" value="Sinnoh" id="sinnoh" /> <label for="sinnoh">Sinnoh</label></td>
    </tr>
  <tr>
    <td><input type="radio" name="wereld" value="Unova" id="unova" /> <label for="unova">Unova</label></td>
    </tr>
  <tr>
<td><td><input type="radio" name="wereld" value="Kalos" id="kalos" /> <label for="kalos">Kalos</label></td>
    </tr>
  <tr>
    <td><input name="submit" type="submit" value="Give Egg" class="button"></td>
    </tr>
</table>
</form>
</center>