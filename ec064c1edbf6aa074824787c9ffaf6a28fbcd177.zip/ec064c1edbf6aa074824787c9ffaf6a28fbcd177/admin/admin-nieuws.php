<?PHP
	include "check.php";
	include "config.php";
	
	if($data->rang != 3 )
	{
		Loading(3, "begin");
		return;
	}	
	require_once "tekst.php";
	?>
    
    <div class="titel"> Admin add news </div>
    
    <?PHP
	if(isset($_POST['update']))
	{
		if($data->rang != 3 )
		exit;
		if(empty($_POST['titel']) || empty( $_POST['content']))
		Fout("One of the specified fields is empty");
		else
		{
			$sql = "INSERT INTO `crimz_news` (`door`,`datum`,`titel`,`bericht`) VALUES('".$data->login."',NOW(),'".$_POST['titel']."','".	$_POST['content']	."')";
			
			if(mysql_query($sql))
			Goed("Post posted");
			else
			Fout("Message could not be posted");
			
		}
	}
	else
	{
	
	
?>

<div class="lijst">
 <form action=""  method="post">
Titel<input type="text" name="titel" value="" >
<textarea style='width: 400px; height:200px' name='content'></textarea>
<input  type="submit" name="update" value="Submit" >
</form>
</div>
<?PHP
	}
?>