<?
header("Location: ../?page=notfound");