<?php
//Admin control
if($gebruiker['admin'] < 3) header('location: index.php?page=home');
    //When the button is clicked
    if(isset($_POST['doneren'])){
        $bedrag = $_POST['bedrag'];
        //See if a number has been entered
        if(ctype_digit($bedrag)){
            //Is the amount greater than 0?
            if($bedrag > 0){
                $melding = '<font color="green">The donation was successful!</font>';
                mysql_query("UPDATE `gebruikers` SET `premiumaccount`=`premiumaccount`+ ".mysql_real_escape_string($bedrag)." WHERE `user_id` > 0");
				$event = '<img src="images/icons/blue.png" width="16" height="16" class="imglower" /> <a href="?page=profile&player='.$gebruiker['username'].'"> gave you free Premium.';
				mysql_query("INSERT INTO gebeurtenis (id, datum, ontvanger_id, bericht, gelezen)
	VALUES (NULL, NOW(), '".$_SESSION['id']."', '".$event."', '0')");
            }else{
                $melding = '<font color="red">The number must be greater than 0!</font>';
            }
        }else{
            $melding = '<font color="red">Please enter a number.</font>';
        }
    }
?>
<?php echo $melding; ?>
<form method="post">
    <label>Donate amount of premium?</label>
    <input type="text" name="bedrag" /><br/><br/>
    <input type="submit" value="Donate" name="doneren" class="button">
</form>