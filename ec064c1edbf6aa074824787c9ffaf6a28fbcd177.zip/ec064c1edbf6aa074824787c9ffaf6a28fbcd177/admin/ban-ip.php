<?php

	//Load script so you can never load page outside of the index
	include("includes/security.php");
	
	if($gebruiker['admin'] < 2) header("Location: index.php?page=home");
	
	#################################################################
	
	if(isset($_POST['ban'])){
		if(empty($_POST['type']))
			echo '<div class="red"><img src="images/icons/red.png"> No type entered.</div>';
		elseif(empty($_POST['gebruiker']))
			echo '<div class="red"><img src="images/icons/red.png"> No user entered.</div>';
		else{
			if($_POST['type'] == 'communicatie') {
				if(empty($_POST['banned'])) {
					echo '<div class="red"><img src="images/icons/red.png"> No communication ban entered.</div>';
				} else {
					mysql_query("INSERT INTO ban (gebruiker, banned, type, datum)
						VALUES ('" . $_POST['gebruiker'] . "', '" . $_POST['banned'] . "', '" . $_POST['type'] . "', NOW())");
					echo '<div class="green"><img src="images/icons/green.png"> '.$_POST['banned'].' successfully communicated a communication plan.</div>';
				}
			} elseif($_POST['type'] == 'chat') {
				if(empty($_POST['gebruiker'])) {
					echo '<div class="red"><img src="images/icons/red.png"> No chat ban entered.</div>';
				} else {
					mysql_query("INSERT INTO ban (gebruiker, banned, type, datum)
						VALUES ('', '" . $_POST['gebruiker'] . "', '" . $_POST['type'] . "', NOW())");
					echo '<div class="green"><img src="images/icons/green.png"> '.$_POST['banned'].' successfully given a chat ban.</div>';
				}
			} elseif($_POST['type'] == 'ipban') {
				$banner = mysql_fetch_array(mysql_query("SELECT ip_ingelogd,username FROM gebruikers WHERE username = '".$_POST['gebruiker']."'"));
				mysql_query("INSERT INTO ban (gebruiker, banned, type, datum)
						VALUES ('".$_POST['gebruiker']."', '', '".$_POST['type']."', NOW())");

				if($banner['username'] == $_POST['gebruiker']) {
					$file = '../.htaccess';
					// Open the file to get existing content
					$current = file_get_contents($file);
					// Append a new person to the file
					$current .= "#Ban ".$_POST['gebruiker']." \nDeny from " . $banner['ip_ingelogd'] . "\n";
					// Write the contents back to the file
					file_put_contents($file, $current);
				}
				echo '<div class="green"><img src="images/icons/green.png"> '.$_POST['gebruiker'].' ban successfully.</div>';
			}
		}
	}
	if(isset($_POST['remove'])){
		mysql_query("DELETE FROM ban WHERE id = '".$_POST['removal']."'");
		echo '<div class="green"><img src="images/icons/green.png"> ban exiled successfully.</div>';
	}

?>
<form method="post" name="ban">
<center>
	<table width="100%" style="border: 1px solid #000;">
    	<tr>
        	<td colspan="2" height="40"><center><strong>Banned users</strong></center></td>
        </tr>
        <tr>
        	<td>Username:</td>
            <td><input type="text" name="gebruiker" class="text_long" value="<?php if($_GET['gebruiker'] != '') echo $_GET['gebruiker'];?>"/></td>
        </tr>
		<tr>
			<td>Communication banned:</td>
			<td><input type="text" name="banned" class="text_long" value=""/><br/><small>*Enter a user here who is no longer allowed to chat with the entered user.</small></td>
		</tr>
        <tr>
        	<td>Type:</td>
			<td><select name="type" class="text_select">
					<?php if($_GET['ip'] != '') {
						echo '<option value="communicatie">Communication</option>
					<option value="ipban" selected>IP Ban</option>
					<option value="chat">Chat Ban</option>';
					} else {
						echo '<option value="communicatie">Communication</option>
					<option value="ipban">IP Ban</option>
					<option value="chat">Chat Ban</option>';
					}
					?>
				</select>
			</td>
        </tr>
        <tr>
            <td colspan="2" align="center"><br/><br/><br/><input type="submit" name="ban" class="button" value="To carry out" /></td>
        </tr>
    </table>
</center>
</form>

<div style="padding-top:30px;"></div>

<center>
	<table width="100%" style="border: 1px solid #000;">
    	<tr>
        	<td colspan="4" height="40"><center><strong>Banned users</strong></center></td>
        </tr>
        <tr>
        	<td><strong>User:</strong></td>
        	<td><strong>User (communication banned):</strong></td>
            <td><strong>Type banned:</strong></td>
            <td><strong>Action:</strong></td>
        </tr>
        <?php
        $query = mysql_query("SELECT * FROM ban ORDER BY id DESC");
		  for($j=$page+1; $ban = mysql_fetch_array($query); $j++)
		  { 
				echo '
					<tr>
						<td>'.$ban['gebruiker'].'</td>
						<td>'.$ban['banned'].'</td>
						<td>'.$ban['type'].'</td>';
				echo '<td><form method="post"><input type="hidden" name="removal" value="'.$ban['id'].'" /><input type="submit" name="remove" class="button_mini" value="Remove"></form></td>';
				echo '</tr>';
		  }
		?>
    </table>
</center>      	