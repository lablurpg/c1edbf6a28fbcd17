<?		
//Load script so you can never load page outside of the index
include("includes/security.php");

//Admin control
if($gebruiker['admin'] < 1) header('location: index.php?page=home');

?>

<form method="post">
  <center><a href="#"><input type="submit" name="aanmeld" value="Users" class="button"></a> - <input type="submit" name="login" value="Logins" class="button"><br /><br /></center>
</form>
<?
//When 1 of the 2 is pressed
if((isset($_POST['aanmeld'])) OR (isset($_POST['login']))){

 //double login
  if(isset($_POST['login'])){
	
		$select = mysql_query("SELECT * FROM `inlog_logs` ORDER BY `datum` LIMIT 0,10")or die(mysql_error());
	
	while ($sel = mysql_fetch_assoc($select)){
		
		
		if(!empty($sel['ip_aangemeld'])) {
			$sele = mysql_query("SELECT `ip` FROM `inlog_logs` WHERE ip='" . $sel['ip'] . "' ") or die(mysql_error());
			
			$tel = mysql_num_rows($sele);
			
			if ($tel > 1) {
				echo $sel['speler'] . " Has logged in double account! <br />";
			}
		}
	}
}
 
 
 //double registration
  if(isset($_POST['aanmeld'])){
	
	$select = mysql_query("SELECT * FROM `gebruikers` ORDER BY `user_id` LIMIT 0,10")or die(mysql_error());
	
	while ($sel = mysql_fetch_assoc($select)){
		
		if(!empty($sel['ip_aangemeld'])) {
			$sele = mysql_query("SELECT `ip_aangemeld` FROM `gebruikers` WHERE ip_aangemeld='" . $sel['ip_aangemeld'] . "' ") or die(mysql_error());
			
			$tel = mysql_num_rows($sele);
			
			if($tel > 1){
			echo $sel['username'] ." Has a double account ! <br />";
			}
		}
	}
  
  }

 }

?>
</table>

