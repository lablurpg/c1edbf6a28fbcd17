<?php
//Admin control
if($gebruiker['admin'] < 3) header('location: index.php?page=home');
    //When the button is clicked
    if(isset($_POST['doneren'])){
        $bedrag = $_POST['bedrag'];
        //See if a number has been entered
        if(ctype_digit($bedrag)){
            //Is the amount greater than 0?
            if($bedrag > 0){
                $melding = '<font color="green">The donation was successful!</font>';
                mysql_query("UPDATE `gebruikers` SET `gold`=`gold`+ ".mysql_real_escape_string($bedrag)." WHERE `user_id` > 0");
            }else{
                $melding = '<font color="red">The amount must be greater than 0!</font>';
            }
        }else{
            $melding = '<font color="red">Enter an amount.</font>';
        }
    }
	//When the button is clicked
    if(isset($_POST['doneren2'])){
        $bedrag = $_POST['bedrag'];
        //See if a number has been entered
        if(ctype_digit($bedrag)){
            //Is the amount greater than 0?
            if($bedrag > 0){
                $melding2 = '<font color="green">The donation was successful!</font>';
                mysql_query("UPDATE `gebruikers` SET `silver`=`silver`+ ".mysql_real_escape_string($bedrag)." WHERE `user_id` > 0");
            }else{
                $melding2 = '<font color="red">The amount must be greater than 0!</font>';
            }
        }else{
            $melding2 = '<font color="red">Enter an amount.</font>';
        }
    }
?>
<?php echo $melding; ?>
<form method="post">
    <label>Donate amount of gold?</label>
    <input type="text" name="bedrag" /><br/><br/>
    <input type="submit" value="Donate" name="doneren" class="button">
</form>
<hr>
<?php echo $melding2; ?>
<form method="post">
    <label>Donate amount of silver?</label>
    <input type="text" name="bedrag" /><br/><br/>
    <input type="submit" value="Donate" name="doneren2" class="button">
</form>