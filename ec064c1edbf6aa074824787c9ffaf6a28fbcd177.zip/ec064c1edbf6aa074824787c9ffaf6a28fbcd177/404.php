<?
header("Location: index.php");