<?
//Load security
include('includes/security.php');

#Load language
$page = 'clan-invite';
#Load good language for the page
include_once('language/language-pages.php');

$getname = $_GET['player'];

#user
$clanquery2 = mysql_query("SELECT clan FROM gebruikers WHERE username='".$_SESSION['naam']."'");
$clan = mysql_fetch_array($clanquery2);
#load clan
$clanquery = mysql_query("SELECT * FROM clans WHERE clan_naam='".$clan['clan']."'");
$profiel = mysql_fetch_array($clanquery);
if(!empty($profiel)){
    $_SESSION['clan'] = $gebruiker['clan'];
?>
<script type="text/javascript">
    function insertSmiley(smiley)
    {
        var currentText = document.getElementById("shoutboxcontent");
        console.log(currentText);
        var smileyWithPadding = " " + smiley + " ";
        currentText.value += smileyWithPadding;
    }
</script>
<center><h2>Clanshout</h2><br>Welcome to the clan shoutbox of <?echo$gebruiker['clan'];?>, only you and your clan members see this shout.</center>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="<? echo $layoutRoot; ?>js/clan-shoutbox.js"></script>
    
<ul id="messages" class="wordwrap">
    <li>Retrieving messages…</li>
</ul>

<form action="shoutbox/clan-sendmessage.php" method="post" id="shoutbox">
    <input id="shoutboxcontent" name="content" class="text_long" style="float:none; width:100%;" maxlength="200" type="text">
    <?
    foreach (insertableEmoticons() as $emoticon) {
        echo $emoticon." ";
    }
    ?>
    <br/><br/>
    <input value="Submit" class="button_mini" style="margin-right:8px;" type="submit">
</form>
<?
} else {
    echo "<center>You dont have a clan, make <a href='?page=clan-make'>here</a> a clan.</center>";
}
?>