<?php
session_start();

?>
<table style="width: 100%;text-align: center;">
    <td style="text-align: center;">
    <a class="button" href="?page=premium/sms&name=<? echo $_GET['name']; ?>">Pay with SMS</a>
    </td>
    <td style="text-align: center;">
    <a class="button" href="?page=premium/paysafecard&name=<? echo $_GET['name']; ?>">Pay with Paysafecard</a>
    </td>
</table>