<table width="100%">
<tr>
  <td align="left">
    <center><a href="index.php?page=bank&x=pinstort"><img src="images/pin.png"></center><br>
    <center>Withdraw &amp; Deposit</a><center>
  </td>
    <?php
    $clanquery = mysql_query("SELECT * FROM clans WHERE clan_naam='".$gebruiker['clan']."'");
    $profiel = mysql_fetch_array($clanquery);
    if($gebruiker['clan'] != ""){
    ?>
    <td align="center">
        <center><a href="index.php?page=bank&x=stortennaarclan"><img src="images/type/<? echo $profiel['clan_type']; ?>.png" width="72px"></center><br>
        <center>Transfer to Clan</a><center>
    </td>
    <?php
    }
    ?>
  <td align="right">
    <center><a href="index.php?page=bank&x=overschrijven"><img src="images/overschrijven.png"></center><br>
    <center>Send to player</a></center>
  </td>
</tr>
</table>
<br/><br/>
<?php 
$bankmax = "999999999999999";
$silver = $gebruiker['silver'];
$gold = $gebruiker['gold'];
$bank = $gebruiker['bank'];
$data->bankleft = $gebruiker['storten'];
$amount = $_POST['amount'];

  if(isset($_POST['out']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
    if($_POST['amount'] <= $bank) {
      $data->silver	= mysql_escape_string($_POST['amount']);
      $data->bank	= mysql_escape_string($_POST['amount']);
      mysql_query("UPDATE `gebruikers` SET `bank`=`bank`-{$data->bank},`silver`=`silver`+{$data->silver} WHERE `username`='{$gebruiker['username']}'");
        mysql_query("INSERT INTO bank_logs (date, sender, receiver, amount, what,type)
                    VALUES (NOW(),'".$gebruiker['username']."','".$gebruiker['username']."','{$data->silver}','withdraw','silver')");
        print "<div class=\"green\">There is <img src=\"images/icons/silver.png\" /> $amount silver debited from your bank account!</div>";
    }
    else
      print "<div class=\"red\">There is not that much silver in your bank account.</div>";
  }
  else if(isset($_POST['in']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
    if($_POST['amount'] <= $silver) {
      if($_POST['amount'] <= $bankmax) {
        if($data->bankleft > 0) {
          $data->silver	= mysql_escape_string($_POST['amount']);
          $data->bank	= mysql_escape_string($_POST['amount']);
          mysql_query("UPDATE `gebruikers` SET `bank`=`bank`+{$data->bank},`silver`=`silver`-{$data->silver},`storten`=`storten`-1 WHERE `username`='{$gebruiker['username']}'");
            mysql_query("INSERT INTO bank_logs (date, sender, receiver, amount, what, type)
                    VALUES (NOW(),'".$gebruiker['username']."','".$gebruiker['username']."','{$data->silver}','deposit','silver')");
        print "<div class=\"green\">There is <img src=\"images/icons/silver.png\" /> $amount credited to your bank account!</div>";
        }
        else
          print "<div class=\"blue\">You cannot deposit today</div>";
      }
      else
        print "<div class=\"red\">You may <img src=\"images/icons/silver.png\" /> {$bankmax} deposit at a time</div>";
    }
    else
      print "<div class=\"red\">You dont have that much silver</div>";
  }
if($_GET['x'] == "pinstort") {
  print '<br/>You can still '.$gebruiker['storten'].'x deposit silver.<br/><br/>
  <table width="60%">
    <tr>
      <td width=100>Cash:</td>
      <td align="right"><img src="images/icons/silver.png" /> '.highamount($gebruiker['silver']).'</td>
    </tr>
    <tr>
      <td width=100>Bank:</td>
      <td align="right"><img src="images/icons/silver.png" /> '.highamount($gebruiker['bank']).'</td>
    </tr>
  </table>
  <form method="post"><table width="60%" align="center">
    <tr>
    <td align="left">
      <img src="images/icons/silver.png" />  Silver: <input type="text" class="bar curved5" name="amount" maxlength="100"> ,- <br/><br/>
      <button type="submit" name="out" class="button">Withdraw</button>
      <button type="submit" name="in" class="button">Deposit</button>
    </td>
    </tr>
  </table></form>';
  
} else if($_GET['x'] == "overschrijven") {

    if(isset($_POST['to'])) {
        if ($_POST['silver']) {
            $to = mysql_escape_string($_POST['to']);
            $amount = mysql_escape_string($_POST['amount']);
            $ontvanger1 = mysql_query("SELECT * FROM `gebruikers` WHERE `username`='{$to}'");
            $ontvanger = mysql_fetch_assoc($ontvanger1);
            if ($ontvanger < 1) {
                print "<div class=\"red\">The name you entered is not correct!</div>";
            } else if ($_POST['silver'] <= $silver) {
                $data->silver = mysql_escape_string($_POST['silver']);
                $data->to = mysql_escape_string($_POST['to']);
                mysql_query("UPDATE `gebruikers` SET `silver`=`silver`-{$data->silver} WHERE `username`='{$gebruiker['username']}'");
                if ($member = mysql_fetch_object(mysql_query("SELECT `username` FROM `gebruikers` WHERE `username`='{$data->to}'"))) {
                    mysql_query("UPDATE `gebruikers` SET `silver`=`silver`+{$data->silver} WHERE `username`='{$ontvanger['username']}'");
                    mysql_query("INSERT INTO bank_logs (date, sender, receiver, amount, what,type)
                    VALUES (NOW(),'".$gebruiker['username']."','".$data->to."','{$data->silver}','transfer','silver')");

                    print "<div class=\"green\">There is <img src=\"images/icons/silver.png\" /> {$data->silver} to {$ontvanger['username']} transferred</div>";
                }
                } else {
                    print "<div class=\"red\">You do not have enough silver cash.</div>";
            }
        }else{
            print "<div class=\"red\">No silver is specified.</div>";
        }
    }
    print <<<ENDHTML
    <br/><br/>
  <form method="post"><table width="60%">
  <tr>
    <td><img src="images/icons/user.png" /> Username:</td>
    <td><input type="text" class="bar curved5" name="to" value="{$_REQUEST['to']}"></td>
  </tr>
  <tr>
    <td><img src="images/icons/silver.png" />  Silver:</td>
    <td><input type="text" class="bar curved5" name="silver" maxlength="100"  value="{$_REQUEST['silver']}"></td>
  </tr>
  <tr>
    <td ><button type="submit" class="button">Transfer</button></td>
  </tr>
  </table></form>
ENDHTML;

} else if($_GET['x'] == "stortennaarclan") {

    if(isset($_POST['to'])) {
        if ($_POST['silver']) {
            $to = mysql_escape_string($_POST['to']);
            $amount = mysql_escape_string($_POST['amount']);
            $ontvanger1 = mysql_query("SELECT * FROM `clans` WHERE `clan_naam`='{$to}'");
            $ontvanger = mysql_fetch_assoc($ontvanger1);
            if ($ontvanger < 1) {
                print "<div class=\"red\">The clan you entered is not correct!</div>";
            } else if ($_POST['silver'] <= $silver) {
                $data->silver = mysql_escape_string($_POST['silver']);
                $data->to = mysql_escape_string($_POST['to']);
                mysql_query("UPDATE `gebruikers` SET `silver`=`silver`-{$data->silver} WHERE `username`='{$gebruiker['username']}'");
                    mysql_query("UPDATE `clans` SET `clan_silver`=`clan_silver`+{$data->silver} WHERE `clan_naam`='{$ontvanger['clan_naam']}'");
                    mysql_query("INSERT INTO bank_logs (date, sender, receiver, amount, what,ype)
                        VALUES (NOW(),'".$gebruiker['username']."','".$ontvanger['clan_naam']."','{$data->silver}','transfer to clan','silver')");
                    print "<div class=\"green\">There is <img src=\"images/icons/silver.png\" /> {$data->silver} to the clan {$ontvanger['clan_naam']} transferred</div>";
            } else {
                print "<div class=\"red\">You do not have enough silver cash.</div>";
            }
        }elseif ($_POST['gold']) {
            $to = mysql_escape_string($_POST['to']);
            $amount = mysql_escape_string($_POST['amount']);
            $ontvanger1 = mysql_query("SELECT * FROM `clans` WHERE `clan_naam`='{$to}'");
            $ontvanger = mysql_fetch_assoc($ontvanger1);
            if ($ontvanger < 1) {
                print "<div class=\"red\">The clan you entered is not correct!</div>";
            } else if ($_POST['gold'] <= $gold) {
                $data->gold = mysql_escape_string($_POST['gold']);
                $data->to = $_POST['to'];
                mysql_query("UPDATE `gebruikers` SET `gold`=`gold`-{$data->gold} WHERE `username`='{$gebruiker['username']}'");
                    mysql_query("UPDATE `clans` SET `clan_gold`=`clan_gold`+{$data->gold} WHERE `clan_naam`='{$ontvanger['clan_naam']}'");
                    mysql_query("INSERT INTO bank_logs (date, sender, receiver, amount, what,type)
                            VALUES (NOW(),'".$gebruiker['username']."','".$ontvanger['clan_naam']."','{$data->gold}','transfer to clan','gold')");
                    print "<div class=\"green\">There is <img src=\"images/icons/gold.png\" /> {$data->gold} to the clan {$ontvanger['clan_naam']} transferred</div>";
            } else {
                print "<div class=\"red\">You dont have enough gold.</div>";
            }
        }else{
            print "<div class=\"red\">No silver or gold has been specified.</div>";
        }
    }
    print <<<ENDHTML
    <br/><br/>
  <form method="post"><table width="60%">
  <tr>
    <td><img src="images/icons/user.png" /> Clan name:</td>
    <td><input type="text" class="bar curved5" name="to" value="{$_REQUEST['to']}"></td>
  </tr>
  <tr>
    <td><img src="images/icons/silver.png" />  Silver:</td>
    <td><input type="text" class="bar curved5" name="silver" maxlength="100"  value="{$_REQUEST['silver']}"></td>
  </tr>
  <tr>
    <td><img src="images/icons/gold.png" />  Gold:</td>
    <td><input type="text" class="bar curved5" name="gold" maxlength="100"  value="{$_REQUEST['gold']}"></td>
  </tr>
  <tr>
    <td ><button type="submit" class="button">Transfer</button></td>
  </tr>
  </table></form>
ENDHTML;

}

?>
