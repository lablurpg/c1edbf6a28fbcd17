<?
#Load script so you can never load page outside of the index
include("includes/security.php");

$page = 'house-seller';
#Load good language for the page
include_once('language/language-pages.php');

  #Name of house you have now:
  if($gebruiker['huis'] == "doos") $huusnu = $txt['house1'];
  elseif($gebruiker['huis'] == "shuis") $huusnu = $txt['house2'];
  elseif($gebruiker['huis'] == "nhuis") $huusnu = $txt['house3'];
  elseif($gebruiker['huis'] == "villa") $huusnu = $txt['house4'];
  elseif($gebruiker['huis'] == "hotel") $huusnu = $txt['house5'];
  elseif($gebruiker['huis'] == "island") $huusnu = $txt['house6'];
	 
#When the Buy button is pressed
if(isset($_POST['koop'])){
  #Building Name
  if($_POST['huis'] == "doos") $huus = $txt['house1'];
  elseif($_POST['huis'] == "shuis") $huus = $txt['house2'];
  elseif($_POST['huis'] == "nhuis") $huus = $txt['house3'];
  elseif($_POST['huis'] == "villa") $huus = $txt['house4'];
  elseif($_POST['huis'] == "hotel") $huus = $txt['house5'];
  elseif($_POST['huis'] == "island") $huus = $txt['house6'];
  #Load data from the house
  $gegevenhuis = mysql_fetch_assoc(mysql_query("SELECT `kosten` FROM `huizen` WHERE `afkorting`='".$_POST['huis']."'"));
  
  #Does the player already have this house?
  if(empty($_POST['huis'])) echo '<div class="red">'.$txt['alert_nothing_selected'].'</div>';
  #Does the player already have this house?
  elseif($_POST['huis'] == $gebruiker['huis']) echo '<div class="red">'.$txt['alert_you_own_this_house'].'</div>';
  #does the player have enough silver?
  elseif($gebruiker['silver'] < $gegevenhuis['kosten']) echo '<div class="red">'.$txt['alert_not_enough_silver'].'</div>';
  #Does the player already have a villa?
  elseif($gebruiker['huis'] == "Villa") echo '<div class="red">'.$txt['alert_already_have_villa'].'</div>';
  #Does the player have a house and want to buy something other than a villa?
  elseif(($gebruiker['huis'] == "nhuis") AND ($_POST['huis'] != "villa")) echo '<div class="red">'.$txt['alert_you_have_better_now'].'</div>';
  #Does the player have a small house and want to buy a box?
  elseif(($gebruiker['huis'] == "shuis") AND ($_POST['huis'] == "doos")) echo '<div class="red">'.$txt['alert_you_have_better_now'].'</div>';
  #Is everything okay then do this
  else{
    #There is an error and message writing
    echo '<div class="green">'.$txt['success_house_1'].' '.$huus.' '.$txt['success_house_2'].'</div>';
    #Save
    mysql_query("UPDATE `gebruikers` SET `silver`=`silver`-'".$gegevenhuis['kosten']."', `huis`='".$_POST['huis']."' WHERE `user_id`='".$_SESSION['id']."'");
  }
}

$keet['1'] = 'disabled';
$keet['2'] = '';
$keet['3'] = '';
$keet['4'] = '';
$keet['5'] = '';
$keet['6'] = '';
$button = '';

if($gebruiker['huis'] == "doos"){
}
elseif($gebruiker['huis'] == "shuis"){
  $keet['2'] = 'disabled';
}
elseif($gebruiker['huis'] == "nhuis"){
  $keet['2'] = 'disabled';
  $keet['3'] = 'disabled';
}
elseif($gebruiker['huis'] == "villa"){
  $keet['1'] = 'disabled';
  $keet['2'] = 'disabled';
  $keet['3'] = 'disabled';
  $keet['4'] = 'disabled';
  $button = 'disabled';
}
elseif($gebruiker['huis'] == "hotel"){
  $keet['1'] = 'disabled';
  $keet['2'] = 'disabled';
  $keet['3'] = 'disabled';
  $keet['4'] = 'disabled';
  $keet['5'] = 'disabled';
  $button = 'disabled';
}
elseif($gebruiker['huis'] == "island"){
  $keet['1'] = 'disabled';
  $keet['2'] = 'disabled';
  $keet['3'] = 'disabled';
  $keet['4'] = 'disabled';
  $keet['5'] = 'disabled';
  $keet['6'] = 'disabled';
  $button = 'disabled';
}

$sql = mysql_query("SELECT * FROM `huizen`");
?>
<form method="post">
<center>
  <table width="660" cellpadding="0" cellspacing="0">
    <tr>
      <td colspan="4"><center><?php echo $txt['title_text']; ?> <strong><?php echo $huusnu; ?></strong>.<br /><br /></center>
      </td>
    </tr>
      <tr>
        <td width="70" class="top_td"><center>#</center></td>
        <td width="140" class="top_td"><center><?php echo $txt['house']; ?></center></td>
        <td width="90" class="top_td"><?php echo $txt['price']; ?></td>
        <td width="360" class="top_td"><?php echo $txt['description']; ?></td>
      </tr>
      <?php
      for($j=1; $select = mysql_fetch_assoc($sql); $j++){
        $prijs = number_format(round($select['kosten']),0,",",".");
        echo '
          <tr>
            <td class="normal_td"><center><input type="radio" name="huis" value="'.$select['afkorting'].'" '.$keet[$j].'/></center></td>
            <td class="normal_td" height="80"><center><img src="'.$select['link'].'" alt="'.$select['naam_'.$_COOKIE['pa_language'].''].'"/></center></td>
            <td class="normal_td"><img src="images/icons/silver.png" title="Silver" style="margin-bottom:-3px;" /> '.$prijs.'</td>
            <td class="normal_td">'.$select['omschrijving_'.$_COOKIE['pa_language'].''].'</td>
          </tr>';
      }
      ?>
      <tr>
        <td colspan="4"><button type="submit" name="koop" class="button"><?php echo $txt['button']; ?></button></td>
      </tr>
  </table>
</center>
</form>