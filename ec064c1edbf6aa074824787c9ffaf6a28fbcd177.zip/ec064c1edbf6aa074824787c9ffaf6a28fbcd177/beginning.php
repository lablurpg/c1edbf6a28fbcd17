<? 
#Load script so you can never load page outside of the index
include("includes/security.php");

$page = 'beginning';
#Load good language for the page
include('language/language-pages.php');

#If the player does not have an egg yet, see the page
if($gebruiker['eigekregen'] == 0){
  #If the button is pressed, the choice is included
  if((isset($_POST['verder'])) OR ($_SESSION['eikeuze'] == 1)){
    $_SESSION['eikeuze'] = 1;
    include('choose-pokemon.php');
  }
  #Otherwise show the page
  else{
  ?>
<center>
        <table width="600" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="120" valign="top"><img src="images/oak.png" /></td>
            <td width="380" valign="top"><p><?php echo $txt['title_text']; ?></p>
            <form method="post" action="index.php?page=choose-pokemon"><button type='submit' name='verder' class='button' ><?php echo $txt['button']; ?></button></form></td>
          </tr>
        </table></center>
  <?
  }#Show or not show page
}
#Player has already had one. Back to home
else{
  header("Location: index.php?page=home");
}
?>