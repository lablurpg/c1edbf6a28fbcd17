<? 
#Load script so you can never load page outside of the index
include("includes/security.php");

$page = 'flip-a-coin';
#Load good language for the page
include_once('language/language-pages.php');

#Is the do button pressed?
if(!empty($_POST['bedrag'])){
  #has an amount been entered?
  if(!preg_match('/[A-Za-z_]+$/',$_POST['bedrag'])){
    #Take a random number 
    $getal = rand(1,99);
    #replace any period in comma
    $bedrag = ($_POST['bedrag']);
    
    if($bedrag > $gebruiker['silver'])
      $bericht = '<div class="red">'.$txt['alert_too_less_silver'].'</div>';
    elseif($bedrag < 1) #Check if the entered amount is more than 0
      $bericht = '<div class="red">'.$txt['alert_amount_unknown'].'</div>';
    elseif(!is_numeric($bedrag)) #is the number numeric?
      $bericht = '<div class="red">'.$txt['alert_amount_unknown'].'</div>';
    elseif($getal < 30){  #Is the number odd
      $bericht = '<div class="green">'.$txt['success_win'].' <img src="images/icons/silver.png" title="Silver" /> '.$bedrag.' silver!</div>';
      mysql_query("UPDATE `gebruikers` SET `silver`=`silver`+'".$_POST['bedrag']."' WHERE `user_id`='".$_SESSION['id']."'");
    }
    else{ #Is the number even
      $bericht = '<div class="red">'.$txt['success_lose'].' <img src="images/icons/silver.png" title="Silver" /> '.$bedrag.' silver!</div>';
      mysql_query("UPDATE `gebruikers` SET `silver`=`silver`-'".$_POST['bedrag']."' WHERE `user_id`='".$_SESSION['id']."'");
    }
  }
  else #No amount has been entered
    $bericht = '<div class="red">'.$txt['alert_no_amount'].'</div>';
}
?>
<script language="JavaScript" type="text/javascript" src="javascripts/numeriek.js"></script>
<? if($bericht) echo $bericht; ?>
<center>
  <table width="56%" border="0">
  <tr>
    <td><center><p><?php echo $txt['title_text']; ?></p></center>
    </td>
  </tr>
  <tr>
    <td><center>
      <table width="230" border="0">
        <form method="post" action="?page=flip-a-coin">
          <tr>                
            <td width="33"><img src="images/icons/silver.png" title="Silver" /> </td>
            <td width="144"><input type="text" class="text_long" value="100" name="bedrag" onKeyPress="onlyNumeric(arguments[0])"></td>
            <td width="45"><button type="submit" name="doen" class="button"><?php echo $txt['button']; ?></button></td>
          </tr>
        </form>
      </table></center>
    </td>
    </tr>
  </table> 
</center>