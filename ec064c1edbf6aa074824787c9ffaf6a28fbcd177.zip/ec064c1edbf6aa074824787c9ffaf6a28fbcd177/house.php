<?php 
	#Load script so you can never load page outside of the index
	include("includes/security.php");
	
	$page = 'house';
	#Load good language for the page
	include_once('language/language-pages.php');

              #Count Pokemon that player has in "house"
              $inhuissql = mysql_fetch_assoc(mysql_query("SELECT COUNT(`id`) AS `aantal` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND (opzak = 'nee' OR opzak = 'tra')"));
			  $inhuis = $inhuissql['aantal'];
              
              if($gebruiker['huis'] == "doos"){
                $huiss = $txt['box'];
                $linkk = "house1.png";
                $over  = 2-$inhuis;
              }
              elseif($gebruiker['huis'] == "shuis"){
                $huiss = $txt['little_house'];
                $linkk = "house2.gif";
                $over  = 20-$inhuis;
              }
              elseif($gebruiker['huis'] == "nhuis"){
                $huiss = $txt['normal_house'];
                $linkk = "house3.gif";
                $over  = 100-$inhuis;
              }
              elseif(($gebruiker['huis'] == "villa") OR ($gebruiker['huis'] == "Villa")){
                $huiss = $txt['big_house'];
                $linkk = "house4.gif";
                $over  = 650-$inhuis;
              }
              elseif(($gebruiker['huis'] == "hotel") OR ($gebruiker['huis'] == "Hotel")){
                $huiss = $txt['hotel'];
                $linkk = "house5.gif";
                $over  = 2500-$inhuis;
			  }
              elseif(($gebruiker['huis'] == "island") OR ($gebruiker['huis'] == "Island")){
                $huiss = $txt['island'];
                $linkk = "house6.png";
                $over  = 10000-$inhuis;
              }else{
                $huiss = $txt['box'];
                $linkk = "house1.png";
                $over  = 0-$inhuis;
              }
              
              $huis = mysql_fetch_assoc(mysql_query("SELECT `ruimte` FROM `huizen` WHERE `afkorting`='".$gebruiker['huis']."'"));
            
              if(isset($_POST['wegbrengen'])){
                #Load data from selected pokemon
                $pokemon_weg = mysql_fetch_assoc(mysql_query("SELECT `id`, `opzak_nummer`, `ei` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND `id`='".$_POST['id']."'"));
                #Count Pokemon in the house
                $pokemoninhuissql = mysql_fetch_assoc(mysql_query("SELECT COUNT(`id`) AS `aantal` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND (opzak = 'nee' OR opzak = 'tra')"));
				$pokemoninhuis = $pokemoninhuissql['aantal'];
				
                #See if the pokemon belongs to the correct player
                if(mysql_num_rows(mysql_query("SELECT `id` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND `id`='".$_POST['id']."'")) == 0)
                  echo '<div class="red">'.$txt['alert_not_your_pokemon'].'</div>';
                #if you don't have a villa and pokemon house is the same size or bigger than your space then you can't bring the pokemon
                elseif(($gebruiker['huis'] != "Villa") AND ($pokemoninhuis >= $huis['ruimte']))
                  echo '<div class="red">'.$txt['alert_house_full'].'</div>';
                else{
                  #Move Pokemon Home
                  mysql_query("UPDATE `pokemon_speler` SET `opzak`='nee', `opzak_nummer`='' WHERE `id`='".$_POST['id']."'");
                  #display on the screen
                  echo '<div class="green">'.$txt['success_bring'].'</div>';
                  #load pokemons you have in your pocket except those you clicked
                  $select1 = mysql_query("SELECT `id`,`opzak_nummer` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND `id`!='".$_POST['id']."' AND `opzak`='ja' ORDER BY `opzak_nummer` ASC");
                  for($i = 1; $select = mysql_fetch_assoc($select1); $i++){
                    #Make all bagging numbers one of the pokemons that remain
                    mysql_query("UPDATE `pokemon_speler` SET `opzak_nummer`='".$i."' WHERE `id`='".$select['id']."'");
                 }
                $over -= 1;
                $gebruiker['in_hand'] -= 1;
                }
              }
              
              #When the button is pressed, this is activated
              if(isset($_POST['ophalen'])){
                #Number of pokemon in your pocket
                if($gebruiker['in_hand'] > 0) mysql_data_seek($pokemon_sql, 0);
                $naampokemon = mysql_fetch_assoc($pokemon_sql);
                #Is the player's hand already full?
                if($gebruiker['in_hand'] == 6)
                  echo '<div class="red">'.$txt['alert_hand_full'].'</div>';
                #Does the player want to bring a Pokémon that is on the transfer list to their hand?
                elseif($naampokemon['transferlijst'] == 'ja')
                  echo '<div class="red">'.$txt['alert_pokemon_on_transferlist'].'</div>';
                else{
                  #On Pocket Number + 1
                  $opzaknummer = $gebruiker['in_hand']+1;
                  #Move Pokemon to hand
                  mysql_query("UPDATE `pokemon_speler` SET `opzak`='ja', `opzak_nummer`='".$opzaknummer."' WHERE `id`='".$_POST['id']."'");
                  #Display on the screen
                  echo '<div class="green">'.$txt['success_get'].'</div>';
                }
                $over += 1;
              }
?>

<table width="600" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="5" valign="top">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td width="26%" rowspan="13"  valign="top">
            <table width="160" border="0">
              <tr>
                <td><center><img src="images/<? echo $linkk; ?>" /></center></td>
              </tr>
              <tr>
                <td><div align="center" style="padding-top:6px;"><strong><? echo $over.' '.$txt['places_over']; ?></strong></div></td>
              </tr>
            </table>
          </td>
        </tr>
        <?
        #Build pages
        switch ($_GET['option']) {
          case "bringaway" :
            echo '<tr>
        			<td width="40" class="top_first_td">'.$txt['#'].'</td>
        			<td width="60" class="top_td">&nbsp;</td>
        			<td width="130" class="top_td">'.$txt['clamour_name'].'</td>
        			<td width="80" class="top_td">'.$txt['level'].'</td>
        			<td width="60" class="top_td">'.$txt['bring_away'].'</td>
        		</tr>';
  	  
            if($gebruiker['in_hand'] > 0) mysql_data_seek($pokemon_sql, 0);
            for($i=1; $pokemon = mysql_fetch_assoc($pokemon_sql); $i++){
              $pokemon = pokemonei($pokemon);
              $pokemon['naam'] = pokemon_naam($pokemon['naam'],$pokemon['roepnaam']);
              $popup = pokemon_popup($pokemon, $txt);
  					  
              #Default
              $shinyimg = 'pokemon';
              $shinystar = '';
              #Shiny?
              if($pokemon['shiny'] == "1.5"){
                $shinyimg = 'shiny';
                $shinystar = '<img src="images/icons/lidbetaald.png" width="16" height="16" style="margin-bottom:-3px;" border="0" alt="Shiny" title="Shiny">';
              }
  		  
              echo '<tr>
          			<td class="normal_first_td">'.$i.'.</td>
          			<td class="normal_td"><a href="#" class="tooltip" onMouseover="showhint(\''.$popup.'\', this)"><img src="'.$pokemon['animatie'].'" width="32" height="32"/></a></td>
          			<td class="normal_td">'.$pokemon['naam'].$shinystar.'</td>
          			<td class="normal_td">'.$pokemon['level'].'</td>
          			<td class="normal_td">
          			  <form method="post">
          				<button type="submit" name="wegbrengen" class="button">'.$txt['button_bring'].'</button>
          				<input type="hidden" name="id" value="'.$pokemon['id'].'">
          			  </form>
          			</td>
          		  </tr>';
            }
			mysql_data_seek($pokemon_sql, 0);
            for ($j=$i; $j<=6; $j++){
              echo '<tr>
              		<td class="normal_first_td" height="28">'.$j.'.</td>
              		<td class="normal_td"><img src="images/items/Poke ball.png"></td>
  			        <td class="normal_td" colspan="4">'.$txt['empty'].'</td>
              	</tr>';
            }          
              
          break;
          
          case "pickup" :
            if(empty($_GET['subpage'])) $subpage = 1; 
            else $subpage = $_GET['subpage'];
            
            #Max number of members per page
            $max = 10; 
            #Count Pokemon
            $aantal_pokemon = mysql_num_rows(mysql_query("SELECT `id` FROM `pokemon_speler` WHERE `user_id`='".$_SESSION['id']."' AND `opzak`='nee'"));
            $aantal_paginas = ceil($aantal_pokemon/$max); 
            $pagina = $subpage*$max-$max; 
            
			      if($aantal_paginas == 0) $aantal_paginas = 1;
            #Load Pokemon from the user he doesn't have in his pocket
            $poke = mysql_query("SELECT pokemon_speler.*, pokemon_wild.naam, pokemon_wild.type1, pokemon_wild.type2
							   FROM pokemon_speler
							   INNER JOIN pokemon_wild
							   ON pokemon_speler.wild_id = pokemon_wild.wild_id
							   WHERE pokemon_speler.user_id='".$_SESSION['id']."' AND pokemon_speler.opzak='nee' ORDER BY pokemon_speler.wild_id ASC LIMIT ".$pagina.", ".$max."");
  
            echo '<tr>
        		  <td width="40" class="top_first_td">'.$txt['#'].'</td>
        		  <td width="60" class="top_td">&nbsp;</td>
        		  <td width="130" class="top_td">'.$txt['clamour_name'].'</td>
        		  <td width="80" class="top_td">'.$txt['level'].'</td>
        		  <td width="60" class="top_td">'.$txt['take'].'</td>
        		</tr>';
    				if($aantal_pokemon == 0){
    					echo '<tr>
    							<td colspan="5" class="normal_first_td">There are no Pokemon in your house.</td>
    						  </tr>';
    				}
    				else{
              for($i=$pagina+1; $pokemon = mysql_fetch_assoc($poke); $i++){
                $pokemon = pokemonei($pokemon);
                $pokemon['naam'] = pokemon_naam($pokemon['naam'],$pokemon['roepnaam']);
                $popup = pokemon_popup($pokemon, $txt);
                #Default
                $shinyimg = 'pokemon';
                $shinystar = '';
                #Shiny?
                if($pokemon['shiny'] == 1){
                  $shinyimg = 'shiny';
                  $shinystar = '<img src="images/icons/lidbetaald.png" width="16" height="16" style="margin-bottom:-3px;" border="0" alt="Shiny" title="Shiny">';
                }
    		  
                echo '<tr>
                  <td class="normal_first_td">'.$i.'.</td>
                  <td class="normal_td"><a href="#" class="tooltip" onMouseover="showhint(\''.$popup.'\', this)"><img src="'.$pokemon['animatie'].'" width="32" height="32" /></a></td>
                  <td class="normal_td">'.$pokemon['naam'].$shinystar.'</td>
                  <td class="normal_td">'.$pokemon['level'].'</td>
                  <td class="normal_td"><form method="post">
                  <div><button type="submit" name="ophalen" class="button">'.$txt['button_take'].'</button></div>
                  <input type="hidden" name="id" value="'.$pokemon['id'].'"></form></td>
                  </tr>';
              }
				    }
            #Page system
            $links = false;
            $rechts = false;
            echo '<tr><td colspan=5><br /><center><div class="sabrosus">';
            if($subpage == 1)
              echo '<span class="disabled"> &lt; </span>';
            else{
              $back = $subpage-1;
              echo '<a href="'.$_SERVER['PHP_SELF'].'?page='.$_GET['page'].'&option=pickup&subpage='.$back.'"> &lt; </a>';
            }
            for($i = 1; $i <= $aantal_paginas; $i++){ 
              if((2 >= $i) && ($subpage == $i))
                echo '<span class="current">'.$i.'</span>';
              elseif((2 >= $i) && ($subpage != $i))
                echo '<a href="'.$_SERVER['PHP_SELF'].'?page='.$_GET['page'].'&option=pickup&subpage='.$i.'">'.$i.'</a>';
              elseif(($aantal_paginas-2 < $i) && ($subpage == $i))
                echo '<span class="current">'.$i.'</span>';
              elseif(($aantal_paginas-2 < $i) && ($subpage != $i))
                echo '<a href="'.$_SERVER['PHP_SELF'].'?page='.$_GET['page'].'&option=pickup&subpage='.$i.'">'.$i.'</a>';
              else{
                $max = $subpage+3;
                $min = $subpage-3;  
                if($subpage == $i)
                  echo '<span class="current">'.$i.'</span>';
                elseif(($min < $i) && ($max > $i))
                	echo '<a href="'.$_SERVER['PHP_SELF'].'?page='.$_GET['page'].'&option=pickup&subpage='.$i.'">'.$i.'</a>';
                else{
                  if($i < $subpage){
                    if(!$links){
                      echo '...';
                      $links = True;
                    }
                  }
                  else{
                    if(!$rechts){
                      echo '...';
                      $rechts = True;
                    }
                  }
                }
              }
            } 
            if($aantal_paginas == $subpage)
              echo '<span class="disabled"> &gt; </span>';
            else{
              $next = $subpage+1;
              echo '<a href="'.$_SERVER['PHP_SELF'].'?page='.$_GET['page'].'&option=pickup&subpage='.$next.'"> &gt; </a>';
            }
            echo "</div></center></td>";
          
          break;
          
          default:
            echo '
              <td height="21" colspan="5"  valign="Top">
              <div style="padding-left:4px;">
              '.$txt['title_text_1'].' '.$huiss.', '.$txt['title_text_2'].' '.$huis['ruimte'].' '.$txt['title_text_3'].'
              </div>
              </td>
            ';
          break;
        }
        ?>
      </table>
  	</td>
  </tr>
</table>