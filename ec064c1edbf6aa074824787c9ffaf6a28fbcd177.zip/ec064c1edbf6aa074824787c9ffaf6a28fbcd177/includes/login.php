<?php 
//When the login button is pressed
if(isset($_POST['login'])){
  //Filter input
  $name = htmlspecialchars(addslashes($_POST['username'])); 
  $ww = htmlspecialchars(addslashes($_POST['password']));
  //Convert password to md5
  $wwmd5 = md5($_POST['password']);
   
  //Loading data for incorrect login.
  $inlog_fout_sql = mysql_query("SELECT `datum`, `ip`, `spelernaam` FROM `inlog_fout` WHERE `ip`='".$_SERVER['REMOTE_ADDR']."' ORDER BY `id` DESC");
  $inlog_fout = mysql_fetch_array($inlog_fout_sql); 
  $aftellen = 1200-(time()-strtotime($inlog_fout['datum']));
   
  //No login name entered
  if($_POST['username'] == '')
    $inlog_error = $txt['alert_no_username'];
  //No password entered
  elseif($ww == '')
    $inlog_error = $txt['alert_no_password'];
  //It went wrong three times
  elseif((mysql_num_rows($inlog_fout_sql) >= 3) AND ($inlog_fout['ip'] === $_SERVER['REMOTE_ADDR']) AND ($aftellen > 0)) {
    $inlog_error = $txt['alert_time_sentence'].' <span><script type="text/javascript">writetimer("'.$aftellen.'")</script></span>';
  }
  else{
    if($aftellen < 0)
      mysql_query("DELETE FROM `inlog_fout` WHERE `ip`='".$_SERVER['REMOTE_ADDR']."'");

    // Load data to look for the user
	$naam = $_POST['username'];
    $gegevens_sql = mysql_query("SELECT `user_id`, `username`, `wachtwoord`, `premiumaccount`, `account_code` FROM `gebruikers` WHERE `username`='".$naam."'"); 
    // Load data to look for the user
    $gegeven_sql  = mysql_query("SELECT `username`, `wachtwoord`, `account_code` FROM `gebruikers` WHERE `wachtwoord`='".$wwmd5."' AND `username`='".$naam."'");
    $gegeven = mysql_fetch_array($gegevens_sql);

    if(mysql_num_rows($gegevens_sql) == 0)
      $inlog_error = $txt['alert_unknown_username'];
    elseif($gegeven['username'] != $naam)
      $inlog_error = $txt['alert_unknown_username'];
    //See if account has not been banned
    elseif(mysql_num_rows(mysql_query("SELECT user_id FROM ban WHERE user_id = '".$gegeven['user_id']."'")) > 0)
  	  $inlog_error = $txt['alert_account_banned'];
    elseif(mysql_num_rows($gegeven_sql) == 0){
      $datum = date("Y-m-d H:i:s");
      mysql_query("INSERT INTO `inlog_fout` (`datum`, `ip`, `spelernaam`, `wachtwoord`) 
        VALUES ('".$datum."', '".$_SERVER['REMOTE_ADDR']."', '".$naam."', '".$ww."')");

      if((mysql_num_rows($inlog_fout_sql) == 2) AND ($gegeven['wachtwoord'] != $wwmd5))
        $inlog_error = $txt['alert_timepenalty'];
      elseif((mysql_num_rows($inlog_fout_sql) == 1) AND ($gegeven['wachtwoord'] != $wwmd5))
        $inlog_error = $txt['alert_trys_left_1'];
      elseif((mysql_num_rows($inlog_fout_sql) == 0) AND ($gegeven['wachtwoord'] != $wwmd5))
        $inlog_error = $txt['alert_trys_left_2'];
    }
    elseif($gegeven['account_code'] != 1)
      $inlog_error = $txt['alert_account_not_activated'];
    else{
      //If Remember Checkbox is checked save cookie
      if($_POST['remember'] == "on"){
        setcookie("pa_1", $gegeven['username'], time()+(60*60*24*365));
        setcookie("pa_2", $_POST['password'], time()+(60*60*24*365));
      }
      
      //Ensure user has 3 attempts again.
      mysql_query("DELETE FROM `inlog_fout` WHERE `ip`='".$_SERVER['REMOTE_ADDR']."'");
      
      //save time the member logs in so the site knows they are online.
      $tijd = time();
      mysql_query("UPDATE `gebruikers` SET `ip_ingelogd`='".$_SERVER['REMOTE_ADDR']."', `online`='".$tijd."' WHERE `username`='".$gegeven['username']."'");
      
      //Request date
      $date = date("Y-m-d H:i:s");
      //Save to the inlog_logs table
      $queryloginlogs = mysql_query("SELECT `id` FROM `inlog_logs` WHERE `ip`='".$_SERVER['REMOTE_ADDR']."' AND `speler`='".$gegeven['username']."'");
      if(mysql_num_rows($queryloginlogs) == "0"){
        mysql_query("INSERT INTO `inlog_logs` (`ip`, `datum`, `speler`) 
          VALUES ('".$_SERVER['REMOTE_ADDR']."', '".$date."', '".$naam."')");
      }
      else
        mysql_query("UPDATE `inlog_logs` SET `datum`='".$date."' WHERE `speler`='".$gegeven['username']."' AND `ip`='".$_SERVER['REMOTE_ADDR']."'");
      
      //put name in variable, so that it can be used later
      $_SESSION['id'] = $gegeven['user_id'];
      $_SESSION['naam'] = $gegeven['username'];
      //Save hash
      $_SESSION['hash'] = md5($_SERVER['REMOTE_ADDR'].",".$gegeven['username']);
      //Are you premium
      if($gegeven['premiumaccount'] > 0)
        $_SESSION['userid'] = $gegeven['id'];
      //send to the ingame page
      header('location: index.php?page=home');
    }
  }
}
?>