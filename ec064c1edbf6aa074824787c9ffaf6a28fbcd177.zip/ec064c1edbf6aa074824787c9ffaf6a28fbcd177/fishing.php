<?php
#Load script so you can never load page outside the index
include("includes/security.php");

?>

<center><td class="border_black"><img src="images/Fisherman.png"></td></center>
<center><h2>Fishing</h2></center>
<hr>

<?php
if($_POST){

if($_POST['rod'] == "1"){
$item = mysql_query("SELECT * FROM `gebruikers_item` WHERE `user_id`='".$_SESSION['id']."' AND `Fishing rod`='1'") OR DIE(mysql_error());
$type = "fishing rod";
$multiple = 0;
}

if(($_POST['rod'] == "") == ($item['Fishing rod'] == 0)){
echo '<div class="red">You dont have a fishing pole.</div>';
$error = 1;
}

if($item['Fishing rod'] == 1){
echo "<div class='red'>You cannot do without one ".$type." fishing.</div>";
$error = 1;
}

//Als vissen al gedaan is
if($gebruiker['fish'] == 0){
if($gebruiker['premiumaccount'] == 0){
	echo '<div class="red">Unfortunately you can no longer fish today.<br/>Premium members can do this 6 times a day. <a href="index.php?page=area-market"><strong>Get premium here!</strong></a></div>';
}else{
	echo '<div class="red">Unfortunately you can no longer fish today.</div>';
}
$error = 1;
}

if($error != 1){

$op1 = "Water";
$op2 = "Ice";

$swappa1 = mysql_query("SELECT * FROM `pokemon_wild` WHERE `wild_id` < '650' AND (`type1`='".$op1."' OR `type1`='".$op2."' OR `type2`='".$op1."' OR `type2`='".$op2."') ORDER BY RAND() Limit 0,1");
$swappah = mysql_fetch_object($swappa1);

$total = $swappah->hp_base + $swappah->attack_base + $swappah->defence_base + $swappah->speed_base;

$total = $total * 73;

$points = rand(1,$total);

$points = $points + $multiple;


mysql_query("UPDATE `gebruikers` SET `fishing`='".$points."',fish=fish-1 WHERE `user_id`='".$_SESSION['id']."'"); 

echo "<table class='finished' width='650' align='center'><tr>";
echo "<td>Right away <b>".$type."</b> Do you have a <b>".$swappah->naam."</b> caught!<br><br><img src='images/pokemon/".$swappah->wild_id.".gif'><br><br>The jury has <b>".number_format($points)." points</b> granted.</td>";
echo "</tr></table>";

}
}
?>

<div class="contentcontent">
<center><br />
Welcome to the fishing tournament.<br /> The fisherman who catches the largest fish receives the top prize.<br /><br />
<b>1st place:</b> 2000 <img src="images/icons/silver.png"><br>
<b>2nd place:</b> 1500 <img src="images/icons/silver.png"><br>
<b>3rd place:</b> 1000 <img src="images/icons/silver.png"><br><br>

<small><b><font color=red>TIP:</font></b> Each new catch overwrites your previous score.</small><br><br>

<br>
<form method="post">
<img src="images/items/Fishing rod.png"></br> Fishing: <input type="radio" name="rod" value="1" <?if($gebruiker['Fishing rod'] == 1){ ?>checked<?php } else { ?> disabled <?php } ?>><br><br>
<button type="submit" name="fish" class="button">Start</button>
</form></center>
</div>
<hr>
<div class="title"><b>Today the best fisherman</b></div>
<table class="general">
	<tr>
		<td width="20"><b>#</b></td>
		<td width="350"><b> Username</b></td>
		<td><b>Score</b></td>
	</tr>
	<?
$profiles1=mysql_query("SELECT username,fishing FROM `gebruikers` ORDER BY `fishing` DESC LIMIT 3");
while($profiles=mysql_fetch_object($profiles1)){

$i++;
if($profiles->fishing != 0) {
	if ($i == 1) {
		$r = "1.";
	}
	if ($i == 2) {
		$r = "2.";
	}
	if ($i == 3) {
		$r = "3.";
	}
	?>
	<tr>
		<td><?= $r ?></td>
		<td><a href="index.php?page=profile&player=<?= $profiles->username ?>"><?= $profiles->username ?></a></td>
		<td><?= number_format($profiles->fishing) ?> Points</td>
	</tr>
<?
}
}
?>

</table>

<div class="title"><b>The best fishermen from yesterday</b></div>
<table class="general">
	<tr>
		<td width="20"><b>#</b></td>
		<td><b>Username</b></td>
	</tr>

<?

$checknumber1 = mysql_query("SELECT * FROM `server` WHERE `id`='1'");
$checknumber = mysql_fetch_object($checknumber1);

$lastwin11 = mysql_query("SELECT username FROM `gebruikers` WHERE `user_id`='$checknumber->fish'");
$lastwin1 = mysql_fetch_object($lastwin11);
$lastwin12 = mysql_query("SELECT username FROM `gebruikers` WHERE `user_id`='$checknumber->fish2'");
$lastwin2 = mysql_fetch_object($lastwin12);
$lastwin13 = mysql_query("SELECT username FROM `gebruikers` WHERE `user_id`='$checknumber->fish3'");
$lastwin3 = mysql_fetch_object($lastwin13);

echo "<tr><td>1.</td><td><a href='index.php?page=profile&player=" . $lastwin1->username . "'>" . $lastwin1->username . "</a></td></tr>";

echo "<tr><td>2.</td><td><a href='index.php?page=profile&player=" . $lastwin2->username . "'>" . $lastwin2->username . "</a></td></tr>";

echo "<tr><td>3.</td><td><a href='index.php?page=profile&player=" . $lastwin3->username . "'>" . $lastwin3->username . "</a></td></tr>";

?>

</table>
