<div class="title">
<h1><i class="fas fa-gamepad"></i><center> About</center></h1>
</div>
			
<section id="about">
		<p>This is an online Lablu RPG with numerous unique features. You can search for powerful Pokémon, build your dream team, and fight against other players! If catching and battling isn't your thing, you can specialize in race and minigames, too! Or you can gather rare and powerful Pokémon -- the possibilities are numerous. Lablu RPG constantly expands and changes, so there will always be something to do! Join now, and be part of the most unique, popular, and quickest growing Lablu RPG ever developed!
		<p><br>Below are the websites, communities and people without which this game would not have been possible:
		<br>
			<a href="https://bulbapedia.bulbagarden.net/">Bulbapedia</a>,
			<a href="http://www.legendarypokemon.net/">LegendaryPokemon</a>,
			<a href="https://veekun.com/">Veekun</a>,
			<a href="https://www.serebii.net/">Serebii</a>,
			<a href="https://www.dragonflycave.com/sprites.aspx">DragonflyCave</a>,
			<a href="https://www.spriters-resource.com">Spriters-Resource</a>.
		</p>
	</section>