﻿
<?php
exit;
$checkuser = mysql_query('SELECT user_id FROM `2014_gifts` WHERE user_id = "'.$_SESSION['id'].'"');
if (mysql_num_rows($checkuser) == 0) {
mysql_query('INSERT INTO `2014_gifts` (user_id) VALUES ("'.$_SESSION['id'].'")');
}

$newyear = mysql_fetch_assoc(mysql_query("SELECT gebruikers_item.*, gebruikers_tmhm.*
											   FROM gebruikers_item
											   INNER JOIN gebruikers_tmhm
											   ON gebruikers_item.user_id = gebruikers_tmhm.user_id
											   WHERE gebruikers_item.user_id = '".$_SESSION['id']."'"));

if(isset($_POST['give'])) {
$_POST['gift']=mysql_real_escape_string($_POST['gift']);
$_POST['player']=mysql_real_escape_string($_POST['player']);
$_POST['text']=mysql_real_escape_string($_POST['text']);
$_POST['gift']=htmlspecialchars($_POST['gift']);
$_POST['player']=htmlspecialchars($_POST['player']);
$_POST['text']=htmlspecialchars($_POST['text']);

if($_POST['gift']=="img/gift-box/arrow.png") { $gift="arrow"; }
if($_POST['gift']=="img/gift-box/candy.png") { $gift="candy"; $price="30000"; $type="silver"; $rating="200"; }
if($_POST['gift']=="img/gift-box/cake.png") { $gift="cake"; $price="80000"; $type="silver"; $rating="1000"; }
if($_POST['gift']=="img/gift-box/chocolates-cookies.png") { $gift="chocolates-cookies"; $price="45"; $type="gold"; $rating="2500"; }
if($_POST['gift']=="img/gift-box/cocktail.png") { $gift="cocktail"; $price="20"; $type="gold"; $rating="1300"; }
if($_POST['gift']=="img/gift-box/cocktail2.png") { $gift="cocktail2"; $price="30"; $type="gold"; $rating="1900"; }
if($_POST['gift']=="img/gift-box/gift-rose.png") { $gift="gift-rose"; $price="45000"; $type="silver"; $rating="1000"; }
if($_POST['gift']=="img/gift-box/heart-of-roses.png") { $gift="heart-of-roses"; $price="140000"; $type="silver"; $rating="3000"; }
if($_POST['gift']=="img/gift-box/ipod.png") { $gift="ipod"; $price="75"; $type="gold"; $rating="4000"; }
if($_POST['gift']=="img/gift-box/pizza.png") { $gift="pizza"; $price="25000"; $type="silver"; $rating="1100"; }
if($_POST['gift']=="img/gift-box/rose.png") { $gift="rose"; $price="15"; $type="gold"; $rating="500"; }
if($_POST['gift']=="img/gift-box/steak.png") { $gift="steak"; $price="65000"; $type="silver"; $rating="1800"; }
if($_POST['gift']=="img/gift-box/teddy.png") { $gift="teddy"; $price="100000"; $type="silver"; $rating="2000"; }
$checkreciever = mysql_num_rows(mysql_query("SELECT user_id FROM `gebruikers` WHERE `username`='".$_POST['player']."'"));

	if($checkreciever == 0) echo '<center><div class="red">The specified player does not exist</div></center>';
	elseif(empty($_POST['player'])) echo '<center><div class="red">Please enter a player name</div></center>';
	elseif($_POST['player']==$gebruiker['username']) echo '<center><div class="red">You cannot send gifts to yourself</div></center>';	
	elseif($gift=="arrow") echo '<center><div class="red">You have not selected a gift</div></center>';
	elseif($_POST['gift']=="") echo '<center><div class="red">You have not selected a gift</div></center>';
	elseif(strlen($_POST['text'])>50) echo '<center><div class="red">The message can contain a maximum of 50 characters</div></center>';
	elseif($gebruiker[$type]<$price) echo '<center><div class="red">You dont have enough silver or gold to send a gift</div></center>';
	elseif(($gebruiker['send_gift']==0) && ($gebruiker['premiumaccount']==0)) echo '<center><div class="red">Normal players can send a maximum of 1 gift per day</div></center>';
	elseif(($gebruiker['send_gift']==0) && ($gebruiker['premiumaccount']>0)) echo '<center><div class="red">Premium members can send a maximum of 2 gifts per day</div></center>';
	else {
		echo '<center><div class="green">The purchased gift was successful '.$_POST['player'].' sent.</div></center>';
		$reciever = mysql_fetch_assoc(mysql_query("SELECT user_id FROM `gebruikers` WHERE `username`='".$_POST['player']."'"));
		mysql_query("INSERT INTO `gifts` (`id`, `gift`, `reciever`, `sender`, `text`) VALUES (NULL, '".$gift."', '".$reciever['user_id']."', '".$gebruiker['user_id']."', '".$_POST['text']."')");
		mysql_query("UPDATE `gebruikers` SET `rating`=`rating`+'".$rating."' WHERE `user_id`='".$reciever['user_id']."'");
		mysql_query("UPDATE `gebruikers` SET `send_gift`=`send_gift`-'1' WHERE `user_id`='".$gebruiker['user_id']."'");
		mysql_query("UPDATE `gebruikers` SET `".$type."`=`".$type."`-'".$price."' WHERE `user_id`='".$gebruiker['user_id']."'");
		$event = '<img src="img/gift-box/gift.png" class="imglower" width="32" /> The player <a href="?page=profile&player='.$gebruiker['username'].'" style="font-weight:bold">'.$gebruiker['username'].'</a> did you <img src="images/icons/'.$type.'.png" /> '.$price.' cleverly.';
		mysql_query("INSERT INTO gebeurtenis (id, datum, ontvanger_id, bericht, gelezen) VALUES (NULL, NOW(), '".$reciever['user_id']."', '".$event."', '0')");
			}
}
?>
<style>
#prices tr td { background:#eee;padding:5px;border-radius:5px; }
</style>
<div id="newyeartitle">
<img src="img/gift-box/teddy.png" class="img" width="24"> 
Gift boutique
<img src="img/gift-box/teddy.png" class="img" width="24"> 
</div>
<div id="newyear">
<img src="img/gift-box/gift.png" style="float:left;" width="200">

<b>Hi <?php echo $gebruiker['username']; ?>!</b><br />
And welcome to the gift shop!<br />
Here you can buy many different gifts and send them to your friends!<br />
The gifts are then in the gift box on their profile.
<br /><br /><b style="color:red">
You cannot give yourself anything!</b><br>
<br />
<center><div class="sep" style="width:690px;"></center>
<br />
<h2>Gifts</h2>
<center>
<table id="prices">
<tr>
	<td align="center"><img src="img/gift-box/teddy.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />100,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +2,000 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/rose.png" width="48"><br /><img src="images/icons/gold.png" style="margin-bottom:-3px;" />15 Gold<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +500 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/ipod.png" width="48"><br /><img src="images/icons/gold.png" style="margin-bottom:-3px;" />75 Gold<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +4,000 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/cake.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />80,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,000 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/candy.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />30,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +200 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/chocolates-cookies.png" width="48"><br /><img src="images/icons/gold.png" style="margin-bottom:-3px;" />45 Gold<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +2,500 Wertung</b>
</td>
</tr>
<tr>
	<td align="center"><img src="img/gift-box/cocktail.png" width="48"><br /><img src="images/icons/gold.png" style="margin-bottom:-3px;" />20 Gold<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,300 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/cocktail2.png" width="48"><br /><img src="images/icons/gold.png" style="margin-bottom:-3px;" />30 Gold<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,900 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/gift-rose.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />45,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,000 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/heart-of-roses.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />140,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +3,000 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/pizza.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />25,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,100 Wertung</b>
</td>
	<td align="center"><img src="img/gift-box/steak.png" width="48"><br /><img src="images/icons/silver.png" style="margin-bottom:-3px;" />65,000 Silver<br /><img src="images/icons/statistics.png" style="margin-bottom:-3px;" /><b> +1,800 Wertung</b>
</td>
</tr>
</table>
</center>

<center><div class="sep" style="width:690px;"></center>
<h2>To send a present</h2>
<center>

<form method="post">
<table id="prize" width="650" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td class="img" width="110"><img id="giftIMG" src="img/gift-box/arrow.png"><br />
		<select onchange="document.getElementById('giftIMG').src=this.options[this.selectedIndex].value;" name="gift">
<option value="img/gift-box/arrow.png">-- Please choose a gift --</option>
<option value="img/gift-box/teddy.png">Teddy Bear</option>
<option value="img/gift-box/rose.png">Rose</option>
<option value="img/gift-box/ipod.png">iPod</option>
<option value="img/gift-box/cake.png">Cake</option>
<option value="img/gift-box/candy.png">Lolly</option>
<option value="img/gift-box/chocolates-cookies.png">Cookies</option>
<option value="img/gift-box/cocktail.png">Cocktail</option>
<option value="img/gift-box/cocktail2.png">Special Cocktail</option>
<option value="img/gift-box/gift-rose.png">Roses Gift</option>
<option value="img/gift-box/heart-of-roses.png">Rose Heart</option>
<option value="img/gift-box/pizza.png">Pizza</option>
<option value="img/gift-box/steak.png">Steak</option>
</select>
		</td>
		<td class="row" width="430">
			<b style="text-decoration:underline;">Receiver:</b> <input type="text"  class="text_long" style="width:200px;" name="player" id="player" placeholder="Spielername" /><br />
			<b style="text-decoration:underline;">A few words or congratulations:</b><br />
			<textarea class="text_area" rows="12" name="text" style="width:380px;height:50px;line-height:25px;" placeholder="-- 50 characters maximum --"></textarea>
		</td>
		<td class="get" width="110"><input type="submit" name="give" value="Senden" class="button_prize"><input type="hidden" name="prizeid" value="2"></td>
	</tr>

</table>
</form>
<br />

</center>
</div>
<link rel="stylesheet" type="text/css" href="img/newyear/css.css" />
