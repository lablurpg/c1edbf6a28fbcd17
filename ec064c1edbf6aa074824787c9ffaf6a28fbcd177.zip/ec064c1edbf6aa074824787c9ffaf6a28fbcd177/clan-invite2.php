<?
#Load language
$page = 'race';
#Load good language for the page
include_once('language/language-pages.php');

#Checks
if(($_GET['id'] == '') || ($_GET['code'] == '') || ($_GET['accept'] == '')) echo '<div class="red"><img src="images/icons/red.png"> Invalid link</div>';
elseif((!is_numeric($_GET['id'])) || (!is_numeric($_GET['code'])) || (!is_numeric($_GET['accept']))) echo '<div class="red"><img src="images/icons/red.png"> Invalid link</div>';
elseif(($_GET['accept'] != 0) && ($_GET['accept'] != 1)) echo '<div class="red"><img src="images/icons/red.png"> Invalid link</div>';
else{
	$sql = mysql_query("SELECT * From clan_invites WHERE invite_id = '".$_GET['id']."' AND code = '".$_GET['code']."'");
	$select = mysql_fetch_assoc($sql);
	$clanquery = mysql_query("SELECT * FROM clans WHERE clan_naam='".$select['invite_clannaam']."'");
	$clan = mysql_fetch_assoc($clanquery);
	$maxspelers = 10*$clan['clan_level'];
	
	
	if(mysql_num_rows($sql) == 0) echo '<div class="blue"><img src="images/icons/blue.png"> Invalid invite.</div>';
	#see if clan is not full.
	elseif($clan['clan_spelersaantal'] == $maxspelers){
		echo '<div class="red">The clan is full</div>';
	}
	#see if users rank is high enough.
	elseif($gebruiker['rank'] < 5 and $_GET['accept'] != 0){
		echo '<div class="red">You must be at least rank 5 to join a clan.</div>';
	}
	else{
		#If accept is 0
		if($_GET['accept'] == 0){
			#remove invite
			mysql_query("DELETE FROM clan_invites WHERE invite_id = '".$_GET['id']."' AND code = '".$_GET['code']."'");
			
			#Write message after what the user's langage is
			$event = '<img src="images/icons/blue.png" width="16" height="16" class="imglower"> Clan invite was declined by '.$select['invite_usernaam'].'';
			
			#Report to the challenger
			mysql_query("INSERT INTO gebeurtenis (id, datum, ontvanger_id, bericht, gelezen)
			VALUES (NULL, NOW(), '".$clan['clan_ownerid']."', '".$event."', '0')");
			
			#Display message FF here
			echo '<div class="green"><img src="images/icons/green.png"> Invite rejected</div>';
		}
		#If accepted
		else{
			mysql_query("UPDATE gebruikers SET clan = '".$select['invite_clannaam']."' WHERE user_id = '".$_SESSION['id']."'");
			mysql_query("UPDATE clans SET clan_spelersaantal = clan_spelersaantal+1  WHERE clan_naam = '".$select['invite_clannaam']."'");
			mysql_query("UPDATE clans SET clan_members = clan_members + '".$_SESSION['id']."'  WHERE clan_naam = '".$select['invite_clannaam']."'");
			mysql_query("DELETE FROM clan_invites WHERE invite_id = '".$_GET['id']."' AND code = '".$_GET['code']."'");
			
			echo '<div class="green"><img src="images/icons/green.png"> Welcome to '.$select['invite_clannaam'].'</div>';
			
			}
			
		}
	}

?>