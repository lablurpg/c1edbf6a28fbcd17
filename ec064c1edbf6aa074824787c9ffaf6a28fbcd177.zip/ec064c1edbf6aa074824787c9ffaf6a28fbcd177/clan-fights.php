<?php
//Load security
include('includes/security.php');

if(($gebruiker['clan'] == "") ) echo '<div class="red">You are not in a clan!</div>';
else {
#Load language
$page = 'clan-fights';

$uid = (int) $_SESSION['id'];

$date = date("d.m.Y");
$expire = date("d.m.Y")+1;

#player strength
$playerstrength_query = mysql_query("SELECT `attack`, `defence`, `spc.attack`, `spc.defence`, `speed`, `opzak`, `user_id`, SUM(`attack` + `defence` + `spc.attack` + `spc.defence` + `speed`) as `endstaerke` FROM `pokemon_speler` WHERE `user_id`='{$uid}' AND `opzak`='ja'");
$playerstrength = mysql_fetch_assoc($playerstrength_query);
mysql_query("UPDATE `gebruikers` SET `playerstrength`='".$playerstrength['endstaerke']."' WHERE `user_id`='{$uid}'");

#clan player check
$clanplayercheck_query = mysql_query("SELECT `clan`, `user_id` FROM `gebruikers` WHERE `user_id`='{$uid}'");
$clanplayercheck = mysql_fetch_assoc($clanplayercheck_query);

#clan strength
$clanstrength_query = mysql_query("SELECT `clan`, `playerstrength`, SUM(`playerstrength`) as `clanstrength` FROM `gebruikers` WHERE `clan`='".$clanplayercheck['clan']."' AND `account_code`='1'");
$clanstrength = mysql_fetch_assoc($clanstrength_query);

$clan_sql = mysql_query("SELECT * FROM `clans` WHERE `clan_naam`='".$clanplayercheck['clan']."'");
$clan_check = mysql_fetch_assoc($clan_sql);

$text1 = "Calculated from the total strength of all Pokémon of the players in the respective clan";
$text2 = "";

#How many clan members are ready?
$clan_rdy_members_query = mysql_query("SELECT `clan`, `clan_fight-ready` FROM `gebruikers` WHERE `clan`='".$clanplayercheck['clan']."' AND `clan_fight-ready`='1'");
$clan_rdy_members = mysql_num_rows($clan_rdy_members_query);
#How many clan members exist?
$clan_members_query = mysql_query("SELECT `clan` FROM `gebruikers` WHERE `clan`='".$clanplayercheck['clan']."'");
$clan_members = mysql_num_rows($clan_members_query);

//End
if((isset($_POST['accept']))){
echo '<center><div class="green">You take part in the attack.</div></center>';
mysql_query("UPDATE `gebruikers` SET `clan_fight-ready`='1' WHERE `user_id`='{$uid}'");
}

if((isset($_POST['decline']))){
echo '<center><div class="red">You declined the attack.</div></center>';
mysql_query("UPDATE `gebruikers` SET `clan_fight-ready`='0' WHERE `user_id`='{$uid}'");
}

if((isset($_POST['submit']))){
//How much money to steal?
$random1 = rand(1, 4);
if($random1 == 1) $abziehen = 7;
elseif($random1 == 2) $abziehen = 8;
elseif($random1 == 3) $abziehen = 9;
elseif($random1 == 4) $abziehen = 10;

$clan_name = mysql_real_escape_string($_POST['naam']);
$clan_level_check_query = mysql_query("SELECT `clan_naam`, `clan_level`, `daily-fights` FROM `clans` WHERE `clan_naam`='".$clan_name."'");
$clan_level_check = mysql_fetch_assoc($clan_level_check_query);
$clan_exist_check_query = mysql_query("SELECT `clan_naam`, `clan_silver`, `bank`, `battle_points` FROM `clans` WHERE `clan_naam`='".$clan_name."'");
$clan_exist_check = mysql_fetch_assoc($clan_exist_check_query);
$clan_exist2 = mysql_query("SELECT `clan` FROM `gebruikers` WHERE `clan`='".$clan_name."'");
$clan_geld_abziehen = round($clan_exist_check['battle_points']/$abziehen);
$gives = htmlspecialchars($_POST['gives']);
#clan strength opponents
$clanstrength_opponents_query = mysql_query("SELECT `clan`, `playerstrength`, SUM(`playerstrength`) as `clanstrength` FROM `gebruikers` WHERE `clan`='".$clan_name."'");
$clanstrength_opponents = mysql_fetch_assoc($clanstrength_opponents_query);
		
		//echo $clanstrength_opponents['clanstrength'];
		//echo '<br>';
		//echo $clanstrength['clanstrength'];
        //echo $clan_check['daily-fights'];
	    //echo '<br>';
		//echo $clan_geld_abziehen_silver;
		//echo '<br>';
        //echo $clan_geld_abziehen_gold;
		//echo '<br>';
		//echo $clan_exist_check['bank'];
		//echo '<br>';
		//echo $clan_exist_check['clan_gold'];

		#Clan founder?
		if($_SESSION['naam'] != $clan_check['clan_owner']){ 
		echo '<div class="red">You are not the clan founder.</div>';
		}
		#Submitted anything?
		else if(empty($clan_name)){
			echo '<div class="red">Please enter a clan name.</div>';
		}
		else if(mysql_num_rows($clan_exist2) == 0){
			echo '<div class="red">This clan does not exist.</div>';
		}
		else if($clan_check['daily-fights'] == 0){
			echo '<div class="red">You cannot make further attacks today.</div>';
		}
		else if($clan_rdy_members != $clan_members){
			echo '<div class="red">Not all players are ready to attack.</div>';
		}
		else if($clan_check['clan_level'] > $clan_level_check['clan_level']+1){
		    echo '<div class="red">The other clans level is too low.</div>';
		}
		else if($clan_members < 2){
		   echo '<div class="red">Your clan must have at least 5 members!</div>';
		}
		else if($clan_exist_check['battle_points'] < 500){
		   echo '<div class="red">The clan has too few battle points<img src="images/battlepoints.png" /></div>';
		}
		
        //All right?
		
		else {
		// + gold
		mysql_query("UPDATE `clans` SET `battle_points`=`battle_points`+'".$clan_geld_abziehen."' WHERE `clan_naam`='".$clanplayercheck['clan']."'");
		// - daily clan fights
		mysql_query("UPDATE `clans` SET `daily-fights`=`daily-fights`-'1' WHERE `clan_naam`='".$clanplayercheck['clan']."'");
		// - gold
		mysql_query("UPDATE `clans` SET `battle_points`=`battle_points`-'".$clan_geld_abziehen."' WHERE `clan_naam`='".$clan_name."'");
		echo "<div class='green'>The attack was successful.</div>";
		}
		}
		
$checkitout_query = mysql_query("SELECT * FROM `clans` WHERE `clan_naam`='".$clanplayercheck['clan']."'");
$checkitout = mysql_fetch_assoc($checkitout_query);

mysql_query("INSERT INTO `clan_items` (clanname, expire) VALUES ('".$checkitout['clan_naam']."', '".$expire."')");		
?>
<?php if($uid == $clan_check['clan_ownerid']) { ?>

<form method="post">
  <center>
    <p><strong>Attacks other clans.</strong><br/><br/></p>
	<p>You and the members of your clan can attack other clans as soon as all members have agreed to the attack!</p>
	<p>The clan with the highest wins <a onmouseover="showhint('<?php echo $text1; ?>.', this)">Overall strength</a></p>
	<p>You can still today <b><?php echo $clan_check['daily-fights']; ?></b> Start attacks.</p>
	<p>The total strength of a clan is: <b><?php echo $clanstrength['clanstrength']; ?></b> <img src="https://pogs.free.fr/WoT/WoT/Image/image%2014%20(BattleResultIcon).png" width="12" height="12" /></p>
    <table width="300">
      <tr>
        <td><label for="naam"><img src="images/icons/clan.png" width="16" height="16" alt="Player" class="imglower" /> Clan:</label></td>
        <td colspan="2"><input type="text" name="naam" id="naam" class="text_long" value="<?php echo $getname; ?>" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2"><input type="submit" name="submit" value="Attack" class="button"></td>
      </tr>
  </table>
  </form>
  </center>
<hr>
<?php } ?>
<center>

<div class="clanfightz">
<h2>Clan fighting</h2>
<div class="info">
You have the option to participate in clan attacks!
Wear yourself and your Pokémon, which you have with you to take part in an attack.<br>
</div>
</div>

	<table width="300" border="0">
        <tr>
        	<td width="50"><strong>#</strong></td>
            <td width="120"><strong>Player</strong></td>
			<td width="150"><strong>Strength</strong></td>
            <td width="120"><strong>Ready?</strong></td>
        </tr>
<?php
$clan_ready_query = mysql_query("SELECT `username`, `clan_fight-ready`, `playerstrength` FROM `gebruikers` WHERE `clan`='".$clanplayercheck['clan']."'");

while($clan_ready = mysql_fetch_array($clan_ready_query)){
if($uid == $clan_check['clan_ownerid']) {
$clan_playerstrength = $clan_ready['playerstrength'];
}
else {
$clan_playerstrength = '****';
}
	
	if($clan_ready['clan_fight-ready'] == 0){ $ready = '<img src="images/icons/alert_red.png" border="0" style="margin-bottom:-3px;">'; }
	else { $ready = '<img src="images/icons/alert_green.png" border="0" style="margin-bottom:-3px;">'; }
	$number ++;

  echo '<tr>
  			<td>'.$number.'.</td>
			<td><a href="index.php?page=profile&player='.$clan_ready['username'].'">'.$clan_ready['username'].'</a></td>
			<td><font color="red"><b>'.$clan_playerstrength.'</b></font></td>
			<td>'.$ready.'</td>
		</tr>';
}		
?>

</table>
<?php if($clan_rdy_members == $clan_members){
echo "<div class='green'>Have it ".$clan_rdy_members."/".$clan_members." Promised to attack clan members!</div>";
}
else{
echo "<div class='red'>Have it ".$clan_rdy_members."/".$clan_members." Promised to attack clan members!</div>";
}
?>
<br>
<?php if($gebruiker['clan_fight-ready'] == 0) { ?>
Do you want to take part in an attack?<br>
<form method="post">
<input type="submit" name="accept" value="Teilnehmen" class="button_mini" style="width:85px;background-color:#cbed91;"> 
</form>
<br>
<?php } ?>
<font color="red">Your strength is calculated from the total strengths of your Pokémon that you are carrying!</font><br>
Your strength: <font color="red"><b><?php echo $playerstrength['endstaerke']; ?></b></font> <img src="https://pogs.free.fr/WoT/WoT/Image/image%2014%20(BattleResultIcon).png" width="12" height="12" /><br>
The total strength of the clan is: <b><?php echo $clanstrength['clanstrength']; ?></b> <img src="https://pogs.free.fr/WoT/WoT/Image/image%2014%20(BattleResultIcon).png" width="12" height="12" />
<style>
.clanfightz {
width: 750px;
height: 120px;
line-height: 34px;
text-align: center;
display: inline-block;
margin-bottom: 4px;
border: 1px solid #ccc;
border-left: 1px dashed #ccc;
border-right: 1px dashed #ccc;
background: #fff url(https://th04.deviantart.net/fs70/PRE/f/2012/126/6/b/elemental_clash___harvey_vs__grace_by_arkeis_pokemon-d4ysoqg.jpg) center  fixed;
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
font-size: 12px;
}
.info{margin-top:20px;background:#fff;box-shadow:0 0 10px #333;border-bottom:1px solid #ccc;border-top:1px solid #ccc;font-weight:700}
h2{background:#fff;width:220px;margin-left:auto;margin-right:auto;border:1px solid #ccc;border-top:0;border-radius:0 0 8px 8px;box-shadow:0 0 10px #333}
</style>
<?php } ?>
