<?php 
	#Load script so you can never load page outside of the index
	include("includes/security.php");	
	
	$page = 'events';
	#Load good language for the page
	include_once('language/language-pages.php');
?>

<script language="javascript">
var checked = 0;
function checkAll() {
  checked = !checked;
  for(i=0; i<document.gebeurtenis.elements.length; i++)
    document.gebeurtenis.elements[i].checked = checked;
}
</script>
<form method="post" name="gebeurtenis">
      <?
      #Set all unread events to read
      if($event_new > 0) mysql_query("UPDATE `gebeurtenis` SET `gelezen`='1' WHERE `ontvanger_id`='".$_SESSION['id']."'");
	  
	  if($gebruiker['premiumaccount'] > 0) $toegestaan = 50;
	  else $toegestaan = 25;
	  
	  #Clear events that are not in the list
	  $hoeveel = mysql_fetch_assoc(mysql_query("SELECT COUNT(id) AS nu FROM gebeurtenis WHERE ontvanger_id = '".$_SESSION['id']."'"));
	  if($toegestaan < $hoeveel['nu']){
		  $delete = $hoeveel['nu']-$toegestaan;
		  mysql_query("DELETE FROM gebeurtenis WHERE ontvanger_id='".$_SESSION['id']."' ORDER BY id ASC LIMIT ".$delete."");
	  }

      if(isset($_POST['verwijder'])){
        #start counter
        $teller = 0;
        #If there is a post id
        if(isset($_POST['eventid'])){
          foreach($_POST['eventid'] as $eventid) {
            #Delete all received IDs
            mysql_query("DELETE FROM `gebeurtenis` WHERE `id`='".$eventid."' AND `ontvanger_id`='".$_SESSION['id']."'");
            if($eventid >= 1) $geselecteerd = true;
            $teller++;
          }
        }
        #If no post id there is this error
        else
          echo '<div class="red">'.$txt['alert_nothing_selected'].'</div><br/><br/>';
        
        #Write text
        $tekst = $txt['alert_more_events_deleted'];
        if($teller == 1)
          $tekst = $txt['alert_one_event_deleted'];

        #If messages have been deleted
        if ($geselecteerd)  echo '<div class="green">'.$tekst.'</div><br/><br/>';
      }
      
      echo '<center><table width="660" cellpadding="0" cellspacing="0">
  			<tr>
			  <td width="30" class="top_first_td"><input type="checkbox" onClick="checkAll()"></td>
			  <td width="130" class="top_td">'.$txt['date-time'].'</td>
			  <td width="500" class="top_td">'.$txt['event'].'</td>
			</tr>';
      
      #Load data
      $event_sql = mysql_query("SELECT `id`, `datum`, `ontvanger_id`, `bericht`, `gelezen` FROM `gebeurtenis` WHERE `ontvanger_id`='".$_SESSION['id']."' and `type` NOT LIKE 'catch' ORDER BY `id` DESC LIMIT 0 , ".$toegestaan."");
      $event_count = mysql_num_rows($event_sql);
	  
      #Building a list per message is automatic
      while($events = mysql_fetch_assoc($event_sql)){ 
	  #Fix the date nicely
	  $datum = explode("-", $events['datum']);
  	  $tijd = explode(" ", $datum[2]);
 	  $datum = $tijd[0]."-".$datum[1]."-".$datum[0].",&nbsp;".$tijd[1];
  	  $datum_finished = substr_replace($datum ,"",-3);
	  
        echo '<tr>
				<td class="normal_first_td"><input type="checkbox" name="eventid[]" value="'.$events['id'].'"></td>
				<td class="normal_td">'.$datum_finished.'</td>
				<td class="normal_td">'.$events['bericht'].'</td>
			  </tr>';
      }
      if($event_count == 0){
        echo '<tr>
				<td colspan="3" class="normal_first_td">'.$txt['no_events'].'</td>
			  </tr>';
      }
      
      ?>
      </tr>
      <tr>
      <td colspan="3"><div style="padding-top:15px;"><button type="submit" name="verwijder" class="button"><?php echo $txt['button']; ?></button></div></td>
    </tr> 
  </table>
  </form>
</center>